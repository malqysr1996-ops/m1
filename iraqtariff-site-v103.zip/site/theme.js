/* Light / dark theme switch. Default is light (unchanged look). Saved per visitor in localStorage. */
(function(){
  var KEY='theme', root=document.documentElement, saved='light';
  try{ saved = localStorage.getItem(KEY) || 'light'; }catch(e){}
  if(saved==='dark') root.setAttribute('data-theme','dark');
  window.__theme = {
    get: function(){ return root.getAttribute('data-theme')==='dark' ? 'dark' : 'light'; },
    set: function(v, persist){
      if(v==='dark') root.setAttribute('data-theme','dark'); else root.setAttribute('data-theme','light');
      if(persist!==false){ try{ localStorage.setItem(KEY, v); }catch(e){} }
      var m=document.querySelector('meta[name="theme-color"]'); if(m) m.setAttribute('content', v==='dark' ? '#3A1420' : '#5B1A2B');
      paint();
    }
  };
  var btns=[];
  function paint(){
    var d = window.__theme.get()==='dark', lbl = d ? 'التبديل إلى الوضع النهاري' : 'التبديل إلى الوضع الليلي';
    btns.forEach(function(b){ b.textContent = d ? '☀️' : '🌙'; b.setAttribute('aria-label', lbl); b.title = lbl; b.setAttribute('aria-pressed', d ? 'true':'false'); });
  }
  function make(){
    var b=document.createElement('button'); b.type='button'; b.className='theme-toggle';
    b.addEventListener('click', function(){ window.__theme.set(window.__theme.get()==='dark' ? 'light' : 'dark'); });
    btns.push(b); return b;
  }
  function mount(){
    if(btns.length) return;
    var hosts=document.querySelectorAll('[data-theme-host]');
    if(hosts.length){            /* page chose where the button lives (home: next to the search title) */
      for(var i=0;i<hosts.length;i++){ var h=make(); h.classList.add('inl'); hosts[i].appendChild(h); }
      paint(); return;
    }
    var header=document.querySelector('header.site'); if(!header) return;
    var btn=make(), nav=header.querySelector('.nav');
    if(header.querySelector('.navbtns')){ btn.classList.add('abs'); header.appendChild(btn); }
    else if(nav){ nav.insertBefore(btn, nav.querySelector('.navbtn')); }
    else header.appendChild(btn);
    paint();
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', mount); else mount();
  /* admin panel is always light (not designed for dark); restored when leaving it */
  document.addEventListener('DOMContentLoaded', function(){
    var v=document.getElementById('view-admin'); if(!v) return;
    var wasDark=false;
    function sync(){
      var open=!v.classList.contains('hidden');
      if(open && window.__theme.get()==='dark'){ wasDark=true; window.__theme.set('light', false); }
      else if(!open && wasDark){ wasDark=false; window.__theme.set('dark', false); }
    }
    new MutationObserver(sync).observe(v,{attributes:true,attributeFilter:['class']}); sync();
  });
})();
