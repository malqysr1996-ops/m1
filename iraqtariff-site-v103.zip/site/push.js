/* Web Push (notifications) for iraqtariff.com — subscription + a small "enable" card.
   Subscriptions are saved in Firestore (pushSubs) through the public REST endpoint, so this file needs no Firebase SDK.
   Use:  <div data-push-card data-kind="general"></div>   or   IQPush.card(el,{kind:'case',caseCode:'TRK-XXXXXX'})   */
(function(){
  'use strict';
  var KEY = 'AIzaSyCI5Pj7C6nXozklApr5QPYmKqbMSKiO-oY', PROJ = 'asicoda', VAPID = 'BIU3Yp0fBCW2pGfo4ajhQdUyKZg1hYJGJp2KOoF9sHbT4qY1fJWRfAHDfxld2dcgRZXbSs1zXm0TLoM2GaxHCkQ';
  var BASE = 'https://firestore.googleapis.com/v1/projects/' + PROJ + '/databases/(default)/documents';
  var LS = { get:function(k){ try{ return localStorage.getItem(k); }catch(e){ return null; } }, set:function(k,v){ try{ localStorage.setItem(k,v); }catch(e){} } };
  var ua = navigator.userAgent || '';
  var ios = /iphone|ipad|ipod/i.test(ua) || (/Macintosh/i.test(ua) && navigator.maxTouchPoints > 1);
  var standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
  function supported(){ return 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window; }
  function flag(kind, code){ return kind === 'case' ? 'pushC_' + code : 'pushG'; }
  function state(kind, code){
    if(ios && !standalone) return 'ios-install';
    if(!supported()) return 'unsupported';
    if(Notification.permission === 'denied') return 'denied';
    return (Notification.permission === 'granted' && LS.get(flag(kind, code)) === '1') ? 'on' : 'off';
  }
  function key2buf(s){ var p = '='.repeat((4 - s.length % 4) % 4), b = atob((s + p).replace(/-/g,'+').replace(/_/g,'/')), a = new Uint8Array(b.length); for(var i=0;i<b.length;i++) a[i] = b.charCodeAt(i); return a; }
  function ab2b64u(buf){ var s = '', a = new Uint8Array(buf); for(var i=0;i<a.length;i++) s += String.fromCharCode(a[i]); return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,''); }
  async function sha(s){ var d = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)); return Array.prototype.map.call(new Uint8Array(d), function(b){ return b.toString(16).padStart(2,'0'); }).join(''); }
  async function reg(){ var r = await navigator.serviceWorker.getRegistration('/'); if(!r) r = await navigator.serviceWorker.register('/sw.js'); await navigator.serviceWorker.ready; return navigator.serviceWorker.getRegistration('/'); }
  async function enable(kind, code){
    if(!supported()) throw new Error('unsupported');
    var perm = Notification.permission === 'granted' ? 'granted' : await Notification.requestPermission();
    if(perm !== 'granted') throw new Error('denied');
    var r = await reg(), sub = await r.pushManager.getSubscription();
    if(!sub) sub = await r.pushManager.subscribe({ userVisibleOnly:true, applicationServerKey: key2buf(VAPID) });
    var j = sub.toJSON(), k = j.keys || {};
    var id = (await sha(j.endpoint)).slice(0, 40) + (kind === 'case' ? '_' + code : '_g');
    var f = { endpoint:{ stringValue:j.endpoint }, p256dh:{ stringValue:k.p256dh || ab2b64u(sub.getKey('p256dh')) }, auth:{ stringValue:k.auth || ab2b64u(sub.getKey('auth')) },
              kind:{ stringValue: kind === 'case' ? 'case' : 'general' }, t:{ timestampValue:new Date().toISOString() }, ua:{ stringValue:(ios ? 'ios' : /android/i.test(ua) ? 'android' : 'web') } };
    if(kind === 'case') f.caseCode = { stringValue:code };
    var res = await fetch(BASE + '/pushSubs/' + id + '?key=' + KEY, { method:'PATCH', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ fields:f }) });
    if(!res.ok) throw new Error('save');
    LS.set(flag(kind, code), '1');
    return true;
  }
  var css = '.pushc{display:flex;gap:12px;align-items:center;background:#fff;border:1.5px solid #E9E0DD;border-radius:16px;padding:12px 14px;margin:0 0 14px;direction:rtl;font-family:inherit}'
   + '.pushc .pi{font-size:26px;flex:none}.pushc .pt{flex:1;min-width:0}.pushc b{display:block;font-size:14px;color:#5B1A2B;line-height:1.5}.pushc small{display:block;font-size:12px;color:#7b6a6f;line-height:1.6}'
   + '.pushc button{flex:none;font-family:inherit;font-weight:800;font-size:13.5px;border:0;border-radius:12px;padding:10px 14px;cursor:pointer;background:linear-gradient(135deg,#EBC24F,#D9A928);color:#2A1118}'
   + '.pushc.ok{border-color:#9bd3b0}.pushc.ok button{display:none}.pushc.violet b{color:#4c1d95}'
   + 'html[data-theme="dark"] .pushc{background:#26191e;border-color:#3d2d32}html[data-theme="dark"] .pushc b{color:#f1e6e9}html[data-theme="dark"] .pushc small{color:#b3a2a7}html[data-theme="dark"] .pushc.violet b{color:#e9d5ff}';
  function card(el, o){
    if(!el) return; o = o || {}; var kind = o.kind === 'case' ? 'case' : 'general', code = o.caseCode || '';
    var st = state(kind, code);
    if(st === 'unsupported' || st === 'on' || (st === 'denied' && !o.showDenied)){ el.innerHTML = ''; return; }   // enabled = job done, nothing left to show
    if(!document.getElementById('pushcss')){ var s = document.createElement('style'); s.id = 'pushcss'; s.textContent = css; document.head.appendChild(s); }
    var title = o.title || (kind === 'case' ? 'نبّهني عند تغيّر مرحلة معاملتي' : 'استلم أخبار الكمارك والتعرفة على جوالك'),
        sub = o.sub || (kind === 'case' ? 'يوصلك إشعار فوراً عند انتقال المعاملة لمرحلة جديدة.' : 'إشعارات قليلة ومفيدة: تحديثات التعرفة وقرارات الكمارك.');
    var ok = st === 'on';
    el.innerHTML = '<div class="pushc' + (ok ? ' ok' : '') + (o.violet ? ' violet' : '') + '"><span class="pi">' + (ok ? '✅' : '🔔') + '</span><div class="pt"><b>' + (ok ? 'الإشعارات مفعّلة' : title) + '</b><small>'
      + (st === 'ios-install' ? 'على الآيفون: ثبّت الموقع أولاً من Safari ← مشاركة ← إضافة إلى الشاشة الرئيسية، ثم افتحه من الأيقونة وفعّل الإشعارات.' : st === 'denied' ? 'الإشعارات محظورة من إعدادات المتصفح لهذا الموقع. فعّلها من الإعدادات ثم حدّث الصفحة.' : ok ? 'تمام، راح يوصلك كل جديد.' : sub) + '</small></div>'
      + (st === 'off' ? '<button type="button">تفعيل</button>' : '') + '</div>';
    var b = el.querySelector('button'); if(!b) return;
    b.addEventListener('click', function(){
      b.disabled = true; b.textContent = '...';
      enable(kind, code).then(function(){ card(el, o); }).catch(function(e){ b.disabled = false; b.textContent = 'تفعيل'; if(e && e.message === 'denied') card(el, Object.assign({ showDenied:true }, o)); else el.querySelector('small').textContent = 'تعذر التفعيل الآن، جرّب مرة ثانية.'; });
    });
  }
  function auto(){ var n = document.querySelectorAll('[data-push-card]'); for(var i=0;i<n.length;i++) card(n[i], { kind:n[i].getAttribute('data-kind') || 'general', caseCode:n[i].getAttribute('data-case') || '', violet:n[i].hasAttribute('data-violet') }); }
  /* friendly ask (our own bubble first, the browser's permission box only after the visitor taps "تفعيل") */
  function nudge(o){
    o = (o && o.title) ? o : {};
    if(state('general') !== 'off') return;
    var kA = o.key ? o.key + 'At' : 'pushNudgeAt', kN = o.key ? o.key + 'N' : 'pushNudgeN';
    var now = Date.now(), at = +(LS.get(kA) || 0), n = +(LS.get(kN) || 0);
    if(at && now - at < (n >= 2 ? 30 : 7) * 86400000) return;
    if(document.querySelector('.pwabar')){ if(!nudge.tried){ nudge.tried = 1; setTimeout(nudge, 20000); } return; }   // never stack on top of the "install app" bar
    if(document.hidden) return;
    if(!document.getElementById('pushcss')){ var st = document.createElement('style'); st.id = 'pushcss'; st.textContent = css; document.head.appendChild(st); }
    var ex = document.createElement('style'); ex.textContent = '.pushn{position:fixed;z-index:75;left:12px;right:12px;bottom:calc(' + (o.bottom == null ? 86 : o.bottom) + 'px + env(safe-area-inset-bottom,0px));max-width:460px;margin:0 auto;background:#fff;border:1.5px solid #D9A928;border-radius:18px;box-shadow:0 14px 34px rgba(0,0,0,.32);padding:14px;direction:rtl;font-family:Tajawal,Tahoma,Arial,sans-serif;animation:pnIn .4s cubic-bezier(.2,.8,.2,1) both}@keyframes pnIn{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:none}}.pushn .r{display:flex;gap:10px;align-items:flex-start}.pushn .pi{font-size:26px}.pushn b{display:block;font-size:14.5px;color:#5B1A2B;line-height:1.5}.pushn small{display:block;font-size:12.5px;color:#6B5A5E;line-height:1.7;margin-top:2px}.pushn .a{display:flex;gap:8px;margin-top:12px}.pushn button{flex:1;font-family:inherit;font-weight:800;font-size:14px;border-radius:12px;padding:10px;cursor:pointer;border:1.5px solid #E9E0DD;background:#fff;color:#5B1A2B}.pushn button.y{border:0;background:linear-gradient(135deg,#EBC24F,#D9A928);color:#2A1118}html[data-theme="dark"] .pushn{background:#26191e;border-color:#D9A928}html[data-theme="dark"] .pushn b{color:#f1e6e9}html[data-theme="dark"] .pushn small{color:#b3a2a7}html[data-theme="dark"] .pushn button:not(.y){background:#32232a;border-color:#3d2d32;color:#f1e6e9}';
    document.head.appendChild(ex);
    var d = document.createElement('div'); d.className = 'pushn'; d.setAttribute('role', 'dialog');
    d.innerHTML = '<div class="r"><span class="pi">🔔</span><div><b>' + (o.title || 'تريد تصلك أخبار الكمارك والتعرفة؟') + '</b><small>' + (o.sub || 'إشعارات قليلة ومفيدة على جوالك، وتكدر توقفها بأي وقت.') + '</small></div></div><div class="a"><button class="y" type="button">' + (o.yes || 'نعم، فعّل') + '</button><button class="n" type="button">لاحقاً</button></div>';
    document.body.appendChild(d);
    function close(){ if(d.parentNode) d.parentNode.removeChild(d); }
    d.querySelector('.n').addEventListener('click', function(){ LS.set(kA, String(Date.now())); LS.set(kN, String(n + 1)); close(); });
    d.querySelector('.y').addEventListener('click', function(){
      var b = this; b.disabled = true; b.textContent = '...';
      enable('general').then(function(){ close(); if(o.done) o.done(); var c = document.getElementById('pushHome'); if(c) card(c, { kind:'general' }); })
        .catch(function(e){ LS.set(kA, String(Date.now())); LS.set(kN, String(n + 1)); close(); });
    });
  }
  function startNudge(){ if(document.getElementById('pushHome')) setTimeout(nudge, 9000); }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', auto); else auto();
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', startNudge); else startNudge();
  window.IQPush = { supported:supported, state:state, enable:enable, card:card, nudge:nudge };
})();
