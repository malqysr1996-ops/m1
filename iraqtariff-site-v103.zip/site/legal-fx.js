/* Soft moving network behind the cards (legal pages only). Rose-burgundy lines, gold glints. */
(function(){
  if(matchMedia('(prefers-reduced-motion:reduce)').matches) return;
  var c=document.createElement('canvas'); c.setAttribute('aria-hidden','true');
  c.style.cssText='position:fixed;inset:0;width:100%;height:100%;z-index:-1;pointer-events:none';
  document.body.insertBefore(c,document.body.firstChild);
  var x=c.getContext('2d'),W,H,P=[],N=(innerWidth<600?26:38),mx=-999,my=-999,sy=0,dpr=Math.min(devicePixelRatio||1,2),last=0;
  function size(){W=c.width=innerWidth*dpr;H=c.height=innerHeight*dpr}
  size(); addEventListener('resize',size);
  for(var i=0;i<N;i++) P.push({x:Math.random(),y:Math.random(),vx:(Math.random()-.5)*.0005,vy:(Math.random()-.5)*.0005,r:1.6+Math.random()*1.8,g:Math.random()<.35});
  addEventListener('pointermove',function(e){mx=e.clientX*dpr;my=e.clientY*dpr},{passive:true});
  addEventListener('scroll',function(){sy=scrollY},{passive:true,capture:true});
  function f(t){
    requestAnimationFrame(f);
    if(t-last<33||document.hidden) return; last=t;
    x.clearRect(0,0,W,H);
    var dark=document.documentElement.getAttribute('data-theme')==='dark', L=Math.min(W,H)*.42;
    P.forEach(function(p){
      p.x+=p.vx*33; p.y+=p.vy*33; if(p.x<0||p.x>1)p.vx*=-1; if(p.y<0||p.y>1)p.vy*=-1;
      p._x=p.x*W; p._y=(((p.y*H-sy*.3*dpr)%H)+H)%H;
      var dx=p._x-mx,dy=p._y-my,d=Math.sqrt(dx*dx+dy*dy)||1;
      if(d<L*.8){p._x+=dx/d*(L*.8-d)*.3;p._y+=dy/d*(L*.8-d)*.3}
    });
    for(var i=0;i<N;i++)for(var j=i+1;j<N;j++){
      var a=P[i],b=P[j],d=Math.hypot(a._x-b._x,a._y-b._y);
      if(d<L){x.strokeStyle=(dark?'rgba(214,120,160,':'rgba(176,70,110,')+(.42*(1-d/L))+')';x.lineWidth=1.1*dpr;x.beginPath();x.moveTo(a._x,a._y);x.lineTo(b._x,b._y);x.stroke()}
    }
    P.forEach(function(p){
      var col=p.g?'233,190,70':'200,100,140',R=p.r*(p.g?5.5:4.5)*dpr;
      var g=x.createRadialGradient(p._x,p._y,0,p._x,p._y,R);g.addColorStop(0,'rgba('+col+',.95)');g.addColorStop(1,'rgba('+col+',0)');
      x.fillStyle=g;x.beginPath();x.arc(p._x,p._y,R,0,7);x.fill();
      x.fillStyle=p.g?'#fff3c9':'#fff';x.beginPath();x.arc(p._x,p._y,p.r*dpr*.8,0,7);x.fill();
    });
  }
  requestAnimationFrame(f);
})();
