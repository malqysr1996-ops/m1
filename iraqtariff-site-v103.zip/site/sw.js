/* Minimal, safe service worker: lets the site be installed and shows a friendly page when offline.
   HTML is always fetched from the network first, so a new deploy is never hidden behind a stale cache. */
const VERSION = 'hs-v100';
const OFFLINE = '/offline.html';
self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll([OFFLINE, '/favicon-192.png', '/theme.js', '/dark.css?v=13'])).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION && k !== 'tariff-data').map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
const IS_OLD_HOST = /netlify\.app$/i.test(self.location.hostname);
self.addEventListener('fetch', e => {
  if (IS_OLD_HOST) return;                                      // old address: let the browser follow the redirect itself
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return;                 // never touch Firebase / Google / CDN requests
  if (url.pathname.startsWith('/.netlify/')) return;           // never cache the bot / functions
  if (/^\/tariff-[a-f0-9]+\.json$/.test(url.pathname)) {        // the tariff table: cache-first, kept offline, old versions removed
    e.respondWith(caches.open('tariff-data').then(c => c.match(req).then(hit => hit || fetch(req).then(r => {
      if (r && r.ok) { c.keys().then(ks => ks.forEach(k => { if (k.url !== req.url) c.delete(k); })); c.put(req, r.clone()); }
      return r;
    }))));
    return;
  }
  if (req.mode === 'navigate') {
    // Pages are always handled by the browser itself (so real server errors/redirects are never hidden).
    // The friendly offline page is used ONLY when the device really is offline.
    if (self.navigator && self.navigator.onLine === false) {
      e.respondWith(fetch(req).catch(() => caches.match(OFFLINE)));
    }
    return;
  }
  if (/\.(png|jpe?g|webp|svg|ico)$/i.test(url.pathname)) {      // images: serve fast, refresh in the background
    e.respondWith(caches.open(VERSION).then(c => c.match(req).then(hit => {
      const net = fetch(req).then(r => { if (r && r.ok) c.put(req, r.clone()); return r; }).catch(() => hit);
      return hit || net;
    })));
  }
});

/* ---- Web Push: show the notification, and count "delivered" / "opened" (public counters in Firestore, no login needed) ---- */
const PUSH_BASE = 'https://firestore.googleapis.com/v1/projects/asicoda/databases/(default)/documents';
const PUSH_KEY = 'AIzaSyCI5Pj7C6nXozklApr5QPYmKqbMSKiO-oY';
function pushStat(cid, field){
  const docs = ['_all'].concat(cid ? [cid] : []);
  const writes = docs.map(id => ({ update:{ name:'projects/asicoda/databases/(default)/documents/pushStats/' + id, fields:{} }, updateMask:{ fieldPaths:[] }, updateTransforms:[{ fieldPath:field, increment:{ integerValue:'1' } }] }));
  return fetch(PUSH_BASE + ':commit?key=' + PUSH_KEY, { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ writes }) }).catch(() => {});
}
self.addEventListener('push', e => {
  let d = {};
  try{ d = e.data ? e.data.json() : {}; }catch(err){ d = { title:'Iraq Tariff', body: e.data ? e.data.text() : '' }; }
  const cid = String(d.cid || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 40);
  e.waitUntil(Promise.all([
    self.registration.showNotification(d.title || 'Iraq Tariff', { body: d.body || '', icon:'/favicon-192.png', badge:'/favicon-96.png', dir:'rtl', lang:'ar', data:{ url: d.url || '/', cid }, tag: cid || undefined, renotify: !!cid }),
    pushStat(cid, 'delivered')
  ]));
});
self.addEventListener('notificationclick', e => {
  e.notification.close();
  const data = e.notification.data || {}, url = new URL(data.url || '/', self.location.origin).href;
  e.waitUntil(Promise.all([
    pushStat(data.cid, 'clicked'),
    self.clients.matchAll({ type:'window', includeUncontrolled:true }).then(list => {
      for(const c of list){ if(c.url.split('#')[0] === url.split('#')[0] && 'focus' in c) return c.focus(); }
      return self.clients.openWindow(url);
    })
  ]));
});
