'use strict';
/* Web Push sender (no external packages: VAPID + RFC 8291 payload encryption with Node crypto).
   POST /.netlify/functions/push-send   Authorization: Bearer <Firebase ID token of the admin or the lawyer>
   body: {mode:'broadcast'|'case', title, body, url, cid, caseCode}
   The subscriptions are read from Firestore WITH THE CALLER'S TOKEN, so Firestore rules decide who may send:
   admin -> everyone, lawyer -> only subscriptions of one case. Dead subscriptions (404/410) are deleted. */
const crypto = require('crypto');
const PROJECT = 'asicoda';
const BASE = 'https://firestore.googleapis.com/v1/projects/' + PROJECT + '/databases/(default)/documents';
const PUB = 'BIU3Yp0fBCW2pGfo4ajhQdUyKZg1hYJGJp2KOoF9sHbT4qY1fJWRfAHDfxld2dcgRZXbSs1zXm0TLoM2GaxHCkQ';
let PRIV = null;
function priv(){ if(PRIV) return PRIV; const j = JSON.parse(require('fs').readFileSync(require('path').join(__dirname, 'vapid-private.json'), 'utf8'));
  PRIV = crypto.createPrivateKey({ key: { kty:'EC', crv:'P-256', d:j.d, x:j.x, y:j.y }, format:'jwk' }); return PRIV; }
const b64u = b => Buffer.from(b).toString('base64url');
const hkdf = (ikm, salt, info, len) => Buffer.from(crypto.hkdfSync('sha256', ikm, salt, info, len));
function vapid(endpoint){
  const aud = new URL(endpoint).origin;
  const h = b64u(JSON.stringify({ typ:'JWT', alg:'ES256' })), c = b64u(JSON.stringify({ aud, exp: Math.floor(Date.now()/1000) + 12*3600, sub:'mailto:m.alqysr1996@gmail.com' }));
  const sig = crypto.sign('sha256', Buffer.from(h + '.' + c), { key: priv(), dsaEncoding:'ieee-p1363' });
  return 'vapid t=' + h + '.' + c + '.' + b64u(sig) + ', k=' + PUB;
}
function encrypt(sub, payload){
  const ua = Buffer.from(sub.p256dh, 'base64url'), auth = Buffer.from(sub.auth, 'base64url');
  const ecdh = crypto.createECDH('prime256v1'); ecdh.generateKeys();
  const asPub = ecdh.getPublicKey(), secret = ecdh.computeSecret(ua);
  const ikm = hkdf(secret, auth, Buffer.concat([Buffer.from('WebPush: info\0'), ua, asPub]), 32);
  const salt = crypto.randomBytes(16);
  const cek = hkdf(ikm, salt, Buffer.from('Content-Encoding: aes128gcm\0'), 16), nonce = hkdf(ikm, salt, Buffer.from('Content-Encoding: nonce\0'), 12);
  const ci = crypto.createCipheriv('aes-128-gcm', cek, nonce);
  const ct = Buffer.concat([ci.update(Buffer.concat([Buffer.from(payload), Buffer.from([2])])), ci.final(), ci.getAuthTag()]);
  const rs = Buffer.alloc(4); rs.writeUInt32BE(4096);
  return Buffer.concat([salt, rs, Buffer.from([asPub.length]), asPub, ct]);
}
const str = f => (f && f.stringValue) || '';
async function listSubs(token, caseCode){
  const eq = (f, v) => ({ fieldFilter:{ field:{ fieldPath:f }, op:'EQUAL', value:{ stringValue:v } } });
  const q = { from:[{ collectionId:'pushSubs' }], limit: 5000 };
  if(caseCode) q.where = { compositeFilter:{ op:'AND', filters:[ eq('kind','case'), eq('caseCode',caseCode) ] } };
  const r = await fetch(BASE + ':runQuery', { method:'POST', headers:{ Authorization:'Bearer ' + token, 'Content-Type':'application/json' }, body: JSON.stringify({ structuredQuery:q }) });
  const j = await r.json().catch(()=>({}));
  const er = Array.isArray(j) ? (j[0] && j[0].error) : j.error;
  if(!r.ok || er) { const e = new Error('firestore'); e.status = (er && er.status) || String(r.status); e.detail = String((er && er.message) || '').slice(0, 160); throw e; }
  return j.filter(x=>x.document).map(x=>({ id:x.document.name.split('/').pop(), endpoint:str(x.document.fields.endpoint), p256dh:str(x.document.fields.p256dh), auth:str(x.document.fields.auth) }));
}
exports.handler = async (event) => {
  const H = { 'Content-Type':'application/json; charset=utf-8', 'Cache-Control':'no-store' };
  if(event.httpMethod !== 'POST') return { statusCode:405, headers:H, body:'{"error":"method"}' };
  const token = String((event.headers.authorization || event.headers.Authorization || '')).replace(/^Bearer\s+/i, '');
  if(!token) return { statusCode:401, headers:H, body:'{"error":"auth"}' };
  let b; try{ b = JSON.parse(event.body || '{}'); }catch(e){ return { statusCode:400, headers:H, body:'{"error":"json"}' }; }
  const title = String(b.title || '').trim().slice(0, 70), body = String(b.body || '').trim().slice(0, 200);
  let url = String(b.url || '/').trim(); if(!/^(\/(?!\/)|https:\/\/iraqtariff\.com)/.test(url)) url = '/';
  const cid = String(b.cid || 'x').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 40) || 'x';
  const caseCode = b.mode === 'case' ? String(b.caseCode || '').toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 14) : '';
  if(!title) return { statusCode:400, headers:H, body:'{"error":"title"}' };
  if(b.mode === 'case' && !caseCode) return { statusCode:400, headers:H, body:'{"error":"case"}' };
  let subs;
  try{ subs = await listSubs(token, caseCode); }catch(e){
    const st = e.status || 'ERR', code = st === 'RESOURCE_EXHAUSTED' || st === '429' ? 503 : st === 'UNAUTHENTICATED' || st === '401' ? 401 : 403;
    return { statusCode:code, headers:H, body: JSON.stringify({ error: st === 'RESOURCE_EXHAUSTED' || st === '429' ? 'quota' : st === 'PERMISSION_DENIED' || st === '403' ? 'forbidden' : st, status: st, detail: e.detail || '' }) };
  }
  const seen = new Set(); subs = subs.filter(s => s.endpoint && s.p256dh && s.auth && !seen.has(s.endpoint) && seen.add(s.endpoint));
  const payload = JSON.stringify({ title, body, url, cid: caseCode ? 'case' : cid });
  let sent = 0, failed = 0, removed = 0;
  for(let i = 0; i < subs.length; i += 25){
    await Promise.all(subs.slice(i, i + 25).map(async s => {
      try{
        const r = await fetch(s.endpoint, { method:'POST', headers:{ Authorization: vapid(s.endpoint), TTL:'86400', Urgency:'high', 'Content-Encoding':'aes128gcm', 'Content-Type':'application/octet-stream' }, body: encrypt(s, payload) });
        if(r.status >= 200 && r.status < 300) sent++;
        else if(r.status === 404 || r.status === 410){ removed++; await fetch(BASE + '/pushSubs/' + encodeURIComponent(s.id), { method:'DELETE', headers:{ Authorization:'Bearer ' + token } }).catch(()=>{}); }
        else failed++;
      }catch(e){ failed++; }
    }));
  }
  return { statusCode:200, headers:H, body: JSON.stringify({ total: subs.length, sent, failed, removed }) };
};
exports._t = { encrypt, vapid };
