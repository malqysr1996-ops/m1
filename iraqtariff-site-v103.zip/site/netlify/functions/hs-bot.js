'use strict';
/* HS-code assistant for the Iraq customs tariff table, powered by Google Gemini (free tier works).
   - Stage "fast": Gemini searches the tariff table (function calling) and picks 1-3 rows.
   - Stage "deep": first a Google-Search-grounded call identifies the product and its HS heading, then the same table search runs with that hint.
   - Every returned code is validated against the table: the model can only answer with rows the search tool returned.
   - Limits (daily total + per visitor) are read from the admin panel (Firestore config/hsBot).
   Required env var: GEMINI_API_KEY.  Optional: GEMINI_MODEL_FAST, GEMINI_MODEL_DEEP (comma lists), RATE_PER_HOUR, ALLOWED_ORIGINS, FIREBASE_API_KEY */

const TABLE = require('./tariff-data.json');   // [hs, desc, rate, prohibited(0/1), ctx]

let FILE_KEY = null;
function fileKey(){   // fallback when Netlify does not pass the env var: key stored in gemini-key.txt next to this file
  if(FILE_KEY !== null) return FILE_KEY;
  try{ const t = require('fs').readFileSync(require('path').join(__dirname, 'gemini-key.txt'), 'utf8').trim(); FILE_KEY = (t && !/^PUT_/i.test(t)) ? t : ''; }catch(e){ FILE_KEY = ''; }
  return FILE_KEY;
}
const KEY = () => process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || fileKey() || '';
const list = (v, d) => (v ? String(v).split(',').map(x=>x.trim()).filter(Boolean) : d);
// several candidates: if Google renames/retires a model, the next one is tried automatically
const MODELS_FAST = () => list(process.env.GEMINI_MODEL_FAST, ['gemini-3.1-flash-lite','gemini-3.5-flash-lite','gemini-3.5-flash']);
const MODELS_DEEP = () => list(process.env.GEMINI_MODEL_DEEP, ['gemini-3.5-flash','gemini-3.1-flash-lite']);
const RATE_PER_HOUR = () => parseInt(process.env.RATE_PER_HOUR || '40', 10);
const FB_KEY = () => process.env.FIREBASE_API_KEY || 'AIzaSyCI5Pj7C6nXozklApr5QPYmKqbMSKiO-oY';
const FB_DOCS = 'https://firestore.googleapis.com/v1/projects/asicoda/databases/(default)/documents';
const DEFAULTS = { enabled:true, dailyCap:300, freePerDay:6 };

/* ---------------- text normalisation + search ---------------- */
const STOP = new Set(['من','في','علي','الي','او','و','ذات','نوع','غير','غيرها','اخري','اخر','مع','بدون','عن','هذا','هذه','للاستعمال','مخصص','خاص','مصنوع','جهاز','اجهزه','قطع','اجزاء']);
function norm(s){
  return String(s||'').toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g,'')
    .replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ؤ/g,'و').replace(/ئ/g,'ي').replace(/ة/g,'ه')
    .replace(/[٠-٩]/g, d=>String(d.charCodeAt(0)-0x0660))
    .replace(/[^\p{L}\p{N}\s]/gu,' ').replace(/\s+/g,' ').trim();
}
function stem(t){
  t = t.replace(/^(وال|بال|كال|فال|لل|ال)/,'');
  if(t.length > 4) t = t.replace(/(ات|ون|ين|ان|ها|ه|ي)$/,'');
  return t;
}
function tokens(s, keepStop){
  return norm(s).split(' ').filter(w=>w.length>=2).map(stem).filter(w=>w.length>=2 && (keepStop || !STOP.has(w)));
}
const DOCS = TABLE.map(r => { const text = norm(r[1]+' '+(r[4]||'')); return { set:new Set(tokens(r[1]+' '+(r[4]||''), true)), text }; });
const DF = new Map();
DOCS.forEach(d => d.set.forEach(t => DF.set(t,(DF.get(t)||0)+1)));
const N = TABLE.length;
const idf = t => Math.log(1 + N/(1+(DF.get(t)||0)));

function searchTable(query, hsPrefix, limit){
  limit = limit || 12;
  const q = tokens(query);
  const prefix = String(hsPrefix||'').replace(/\D/g,'');
  const scored = [];
  for(let i=0;i<N;i++){
    let s = 0;
    if(prefix){ if(!TABLE[i][0].startsWith(prefix)) continue; s += 5; }
    const d = DOCS[i];
    let hit = 0;
    for(const t of q){
      if(d.set.has(t)){ s += idf(t); hit++; }
      else if(t.length >= 3 && d.text.includes(t)){ s += idf(t)*0.6; hit++; }
    }
    if(q.length && !prefix && hit === 0) continue;
    if(q.length) s += (hit/q.length) * 2;
    if(s > 0) scored.push([s,i]);
  }
  scored.sort((a,b)=> b[0]-a[0] || a[1]-b[1]);
  return scored.slice(0,limit).map(x=>x[1]);
}
function fmtRow(i){
  const r = TABLE[i];
  return i+' | '+r[0]+' | '+r[1]+(r[4]?' [سياق: '+r[4]+']':'')+' | '+(r[2]!==''?r[2]+'%':'؟')+(r[3]?' | ممنوع الاستيراد':'');
}

/* ---------------- Gemini ---------------- */
const TOOLS = [{ functionDeclarations: [
  { name:'search_tariff',
    description:'Search the Iraq customs tariff table. Give Arabic keywords (try singular/plural and synonyms) and/or an HS prefix of digits (e.g. "8415"). Returns up to 12 rows as: idx | hs | description [context] | duty rate.',
    parameters:{ type:'OBJECT', properties:{ query:{type:'STRING', description:'Arabic keywords describing the goods'}, hs_prefix:{type:'STRING', description:'Optional digits the HS code starts with'} } } },
  { name:'submit_answer',
    description:'Submit the final answer. Call this exactly once when done.',
    parameters:{ type:'OBJECT', required:['status'], properties:{
      status:{ type:'STRING', enum:['answer','need_info','unsure','reply','need_web'] },
      text:{ type:'STRING', description:'Arabic answer text when status is reply (max about 110 words, plain text, short lines allowed)' },
      handoff:{ type:'BOOLEAN', description:'true when the user should also be offered the human expert (specific case, fees, legal decision, or you are not fully sure)' },
      question:{ type:'STRING', description:'ONE short Arabic question when status is need_info' },
      note:{ type:'STRING', description:'Optional one-sentence Arabic note (for example what the web research found)' },
      results:{ type:'ARRAY', items:{ type:'OBJECT', required:['idx','confidence','reason'], properties:{
        idx:{ type:'INTEGER', description:'idx exactly as returned by search_tariff' },
        confidence:{ type:'STRING', enum:['closest','possible'] },
        reason:{ type:'STRING', description:'One simple Arabic sentence explaining why this row fits' } } } } } } }
] }];

const SYSTEM_BASE = `You help importers in Iraq find the right customs tariff row for their goods.
You work ONLY with the table returned by the search_tariff function. Never answer with a code from memory: every answer must be an idx that search_tariff returned in this conversation. You MAY use your general knowledge of the Harmonized System only to guess the likely 4-digit heading and then search with it as hs_prefix, because the table's descriptions are terse and often miss everyday words (for example refrigerators or laptops).
Procedure:
1. Understand the goods (the user may write Iraqi dialect Arabic, fusha or English). Search with Arabic keywords as written in tariff tables (formal terms, singular/plural, synonyms) AND with the likely 4-digit heading as hs_prefix (try both, and also a 6-digit prefix once you see the right heading). Search several times if needed.
2. Read each row's description and its [context] (generic rows such as "غيرها" take their meaning from the context).
3. If one row clearly fits, answer with exactly ONE result (confidence "closest"). If several rows are plausible, answer with up to THREE results, best first: the best is "closest", the others "possible".
4. If the goods are too vague to classify (for example just "spare parts"), call submit_answer with status "need_info" and ONE short Arabic question about material, function or use.
5. If you searched properly and nothing fits, call submit_answer with status "unsure".
6. Write every reason and note in simple, correct Arabic, one sentence each. Do not mention duty rates (the app shows them).
If the message already contains preliminary table search results and one of them clearly fits, call submit_answer IMMEDIATELY without searching again (this is much faster). Search only when they do not contain the right row.
Call submit_answer exactly once at the end.`;
const GENERAL_RULES = `
You are ALSO the general assistant of an Iraqi customs-broker website. Besides classifying goods you answer questions about importing into Iraq and about the site's services.
How to choose the status:
- The user names goods, or gives an HS code / heading, or asks for the duty rate of an item: follow the procedure above (search_tariff, then status "answer"). If the user gives digits, search with hs_prefix.
- A general question that you can answer reliably (how customs clearance works, what documents are usually needed, the difference between the advance and the final declaration, what the site offers, how to use the calculator or container tracking): call submit_answer with status "reply", put a clear, friendly Arabic answer in "text" (simple words, at most about 110 words, short lines), and set handoff=true if the answer depends on the user's specific case.
- A question that depends on current rules or figures that you cannot know for sure (today's exchange rate, new customs decisions, fees or regulations that change, port or border news): status "need_web". Do not guess.
- A greeting or thanks: status "reply" with a short friendly answer that invites the user to ask.
- Never invent duty rates, fees, prices, laws or deadlines. Prices of the owner's services may only come from the facts below; otherwise say the expert will quote the price on WhatsApp and set handoff=true.
- Answer in the language the user wrote in (Arabic by default; Iraqi dialect is fine for understanding, but write clear simple Arabic).
- The user may ask to speak to a person or says the answer is wrong: status "reply", a one-line polite answer, handoff=true.
Facts about this site (always true):
- Free tools: customs duty calculator (HS code or goods description), tariff search, landed-cost estimate, container tracking (opens the shipping line's official page), and this assistant that suggests the tariff item.
- Paid / expert services via WhatsApp: expert audit of the tariff item, container audit (location, expected arrival and other details) for 10,000 Iraqi dinars per container, document amendment, and filing the advance and final customs declarations.
- Estimates shown by the site are indicative; the final classification and amounts depend on the Iraqi customs decision.`;
const WEB_PROMPT = `Identify the product the user describes. Use web search. Reply in Arabic in at most 70 words: what the product is, its material/function/use, its likely international HS heading (4 to 6 digits), and 3 to 6 names (Arabic and English) under which it appears in customs tariffs. Do not add anything else.`;

const VISION_PROMPT = `You identify products from photos so that an importer can find the customs tariff row. Look carefully at the photo, including any visible text, brand, model number, label, packaging or specifications. If the product is not obvious, use web search to find out what it is. Reply in Arabic in at most 80 words: what the product is, its material/function/use, its likely international HS heading (4 to 6 digits), and 3 to 6 names (Arabic and English) under which it appears in customs tariffs. If you really cannot tell what it is, say so briefly. Do not add anything else.`;
let goodModel = { fast:null, deep:null };
async function gemini(kind, body, timeoutMs, opts){
  opts = opts || {};
  const cands = kind==='deep' ? MODELS_DEEP() : MODELS_FAST();
  const order = goodModel[kind] && cands.includes(goodModel[kind]) ? [goodModel[kind]].concat(cands.filter(m=>m!==goodModel[kind])) : cands;
  let lastErr;
  for(let attempt=0; attempt<2; attempt++){
   if(attempt===1){
     if(opts.noRetry || !(lastErr && (lastErr.status===429 || lastErr.status===503))) break;   // only retry for busy / rate-limit errors
     await new Promise(r=>setTimeout(r, 1200));
   }
  for(const model of order){
    const ctrl = new AbortController();
    const t = setTimeout(()=>ctrl.abort(), Math.max(1500, timeoutMs));
    try{
      const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent', {
        method:'POST', signal:ctrl.signal,
        headers:{ 'content-type':'application/json', 'x-goog-api-key':KEY() },
        body: JSON.stringify(body)
      });
      const j = await r.json().catch(()=>({}));
      if(!r.ok){
        const msg = (j && j.error && j.error.message) || ('API '+r.status);
        const e = Object.assign(new Error(msg), { status:r.status });
        if(r.status===404 || r.status===429 || r.status===503 || (r.status===400 && /not found|not supported|unknown model|invalid model/i.test(msg))){ lastErr = e; continue; }   // try the next model (also when one model is out of quota/overloaded)
        throw e;
      }
      goodModel[kind] = model;
      return j;
    } finally { clearTimeout(t); }
  }
  }
  throw lastErr || new Error('no model available');
}
const toContents = h => h.map(m=>({ role: m.role==='assistant' ? 'model' : 'user', parts:[{ text:m.content }] }));
const partsOf = j => ((j && j.candidates && j.candidates[0] && j.candidates[0].content && j.candidates[0].content.parts) || []);

async function webHint(history, budgetMs){
  const j = await gemini('deep', {
    systemInstruction:{ parts:[{ text: WEB_PROMPT }] },
    contents: toContents(history), tools:[{ google_search:{} }],
    generationConfig:{ temperature:0.2, maxOutputTokens:600 }
  }, budgetMs, { noRetry:true });
  return partsOf(j).filter(p=>typeof p.text==='string').map(p=>p.text).join(' ').trim().slice(0,700);
}

const WEB_ANSWER_PROMPT = `You help importers in Iraq. Answer the user's question using web search, focusing on Iraq (customs, import rules, procedures, official announcements). Reply in clear simple Arabic in at most 110 words. State only what the search supports. If the sources are unclear, outdated or conflicting, say so honestly and do not guess numbers. Do not add greetings.`;
async function webAnswer(history, budgetMs){
  const j = await gemini('deep', {
    systemInstruction:{ parts:[{ text: WEB_ANSWER_PROMPT }] },
    contents: toContents(history), tools:[{ google_search:{} }],
    generationConfig:{ temperature:0.2, maxOutputTokens:700 }
  }, budgetMs, { noRetry:true });
  return partsOf(j).filter(p=>typeof p.text==='string').map(p=>p.text).join(' ').trim().slice(0,900);
}
async function describeImage(image, userText, budgetMs){
  const m = String(image).match(/^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$/);
  if(!m) return { text:'', usedWeb:false };
  const t0 = Date.now();
  const mk = (tools) => ({
    systemInstruction:{ parts:[{ text: VISION_PROMPT }] },
    contents:[{ role:'user', parts:[ { inline_data:{ mime_type:m[1], data:m[2] } }, { text: (userText ? 'Note from the user: ' + userText + '\n' : '') + 'What is this product?' } ] }],
    ...(tools ? { tools } : {}), generationConfig:{ temperature:0.2, maxOutputTokens:500 }
  });
  const read = j => partsOf(j).filter(p=>typeof p.text==='string').map(p=>p.text).join(' ').trim().slice(0,450);
  try{                                                   // 1st: identify with Google Search help (like a reverse image search)
    const j = await gemini('deep', mk([{ google_search:{} }]), Math.min(14000, budgetMs), { noRetry:true });
    const text = read(j); if(text) return { text, usedWeb:true };
  }catch(e){ /* search quota / unavailable: fall through to plain vision */ }
  const left = budgetMs - (Date.now()-t0); if(left < 2500) return { text:'', usedWeb:false };
  const j2 = await gemini('deep', mk(null), left);
  return { text: read(j2), usedWeb:false };
}

async function classify(mode, history, budgetMs, opts){
  opts = opts || {};
  const exclude = opts.exclude || new Set();
  const t0 = Date.now();
  const deep = mode === 'deep';
  let usedWeb = false, hint = '', webErr = '';
  if(deep && opts.general){
    const txt = await webAnswer(history, Math.min(22000, budgetMs));
    if(!txt) return { status:'unsure', usedWeb:true };
    return { status:'reply', text:txt, handoff:true, usedWeb:true };
  }
  if(deep){
    try{ hint = await webHint(history, Math.min(12000, budgetMs*0.5)); usedWeb = !!hint; }catch(e){ webErr = (e && (e.status||e.name)) || 'err'; /* Google Search is rate-limited / not available: continue WITHOUT it instead of failing the whole answer */ }
  }
  let system = SYSTEM_BASE + GENERAL_RULES;
  if(opts.knowledge) system += '\nExtra facts provided by the site owner (trust these over general knowledge):\n' + String(opts.knowledge).slice(0,3000);
  if(exclude.size) system += '\nThe user REJECTED these HS codes as not suitable, so NEVER return them again: ' + Array.from(exclude).join(', ') + '. Find DIFFERENT candidates: widen the search (other headings, other wording, other materials/uses) and say in "reason" how each differs.';
  if(hint) system += '\nThis is a HARD case. Web research about the product found (use it to choose the HS heading, then confirm with search_tariff): ' + hint + '\nPut one Arabic sentence in "note" saying what the web research found.';
  const contents = toContents(history);
  const seen = new Set();
  const maxIter = deep ? 7 : 4;
  try{
    const lastUser = opts.query || history[history.length-1].content;
    const pre = searchTable(lastUser, '', 12).filter(i=>!exclude.has(String(TABLE[i][0])));
    if(pre.length){
      pre.forEach(i=>seen.add(i));
      const last = contents[contents.length-1];
      last.parts = [{ text: last.parts[0].text + '\n\n[Preliminary table search results for the user words above]\n' + pre.map(fmtRow).join('\n') }];
    }
  }catch(e){}

  for(let it=0; it<maxIter; it++){
    const left = budgetMs - (Date.now()-t0);
    if(left < 2000) return { status:'unsure', timedOut:true, usedWeb };
    const j = await gemini(deep?'deep':'fast', {
      systemInstruction:{ parts:[{ text: system }] }, contents, tools:TOOLS,
      toolConfig:{ functionCallingConfig:{ mode:'ANY' } },
      generationConfig:{ temperature:0.2, maxOutputTokens:1024 }
    }, left);
    const cand = j.candidates && j.candidates[0];
    if(!cand || !cand.content) return { status:'unsure', usedWeb };
    contents.push(cand.content);                                   // echo the model turn back untouched (keeps any thought signatures)
    const calls = partsOf(j).filter(p=>p.functionCall).map(p=>p.functionCall);
    const submit = calls.find(c=>c.name==='submit_answer');
    if(submit) return finalize(submit.args || {}, seen, usedWeb, exclude);
    if(!calls.length) return { status:'unsure', usedWeb };
    const responses = calls.map(c=>{
      if(c.name !== 'search_tariff') return { functionResponse:{ name:c.name, response:{ result:'unknown function' } } };
      const a = c.args || {};
      const idxs = searchTable(String(a.query||'').slice(0,200), String(a.hs_prefix||'').slice(0,8), 12).filter(i=>!exclude.has(String(TABLE[i][0])));
      idxs.forEach(i=>seen.add(i));
      return { functionResponse:{ name:'search_tariff', response:{ result: idxs.length ? idxs.map(fmtRow).join('\n') : 'no rows found' } } };
    });
    contents.push({ role:'user', parts:responses });
  }
  return { status:'unsure', usedWeb };
}

function finalize(inp, seen, usedWeb, exclude){
  exclude = exclude || new Set();
  const status = inp.status;
  const note = typeof inp.note === 'string' ? inp.note.slice(0,300) : '';
  if(status === 'reply' && typeof inp.text === 'string' && inp.text.trim())
    return { status:'reply', text: inp.text.trim().slice(0,900), handoff: inp.handoff === true, usedWeb };
  if(status === 'need_web') return { status:'need_web', usedWeb };
  if(status === 'need_info' && typeof inp.question === 'string' && inp.question.trim())
    return { status:'need_info', question: inp.question.trim().slice(0,300), usedWeb };
  if(status === 'answer' && Array.isArray(inp.results)){
    const out = [], used = new Set();
    for(const r of inp.results){
      const i = Number(r && r.idx);
      if(!Number.isInteger(i) || i<0 || i>=N || !seen.has(i) || used.has(i) || exclude.has(String(TABLE[i][0]))) continue;   // reject anything the table search did not return
      used.add(i);
      const row = TABLE[i];
      out.push({ idx:i, hs:row[0], desc:row[1]||'', ctx:row[4]||'', rate:row[2], prohibited:!!row[3],
                 confidence: r.confidence === 'closest' ? 'closest' : 'possible', reason: String(r.reason||'').slice(0,300) });
      if(out.length === 3) break;
    }
    if(out.length){ if(!out.some(x=>x.confidence==='closest')) out[0].confidence = 'closest'; return { status:'answer', results:out, note, usedWeb }; }
  }
  return { status:'unsure', note, usedWeb };
}

/* ---------------- admin-controlled limits (Firestore REST, public-readable config) ---------------- */
const num = f => f ? Number(f.integerValue !== undefined ? f.integerValue : (f.doubleValue !== undefined ? f.doubleValue : NaN)) : NaN;
let cfgCache = { t:0, v:DEFAULTS };
async function fbGet(path, ms){
  const ctrl = new AbortController(); const t = setTimeout(()=>ctrl.abort(), ms||2500);
  try{ const r = await fetch(FB_DOCS+'/'+path+'?key='+encodeURIComponent(FB_KEY()), { signal:ctrl.signal }); if(!r.ok) return null; return await r.json(); }
  catch(e){ return null; } finally { clearTimeout(t); }
}
async function loadCfg(){
  if(Date.now() - cfgCache.t < 60000) return cfgCache.v;
  const d = await fbGet('config/hsBot');
  const f = (d && d.fields) || {};
  const v = Object.assign({}, DEFAULTS);
  if(f.enabled && f.enabled.booleanValue === false) v.enabled = false;
  const dc = num(f.dailyCap), fp = num(f.freePerDay);
  if(Number.isFinite(dc) && dc >= 0) v.dailyCap = dc;
  if(Number.isFinite(fp) && fp >= 1) v.freePerDay = fp;
  if(f.knowledge && typeof f.knowledge.stringValue === 'string') v.knowledge = f.knowledge.stringValue.slice(0,3000);
  cfgCache = { t:Date.now(), v };
  return v;
}
const dayKey = () => 'botDay_' + new Date().toISOString().slice(0,10).replace(/-/g,'');
const dayCounter = { key:'', n:0 };
async function globalCount(){
  const k = dayKey();
  const d = await fbGet('config/stats');
  const n = num(d && d.fields && d.fields[k]);
  if(Number.isFinite(n)){ dayCounter.key = k; dayCounter.n = Math.max(dayCounter.n, n); return n; }
  if(dayCounter.key !== k){ dayCounter.key = k; dayCounter.n = 0; }
  return dayCounter.n;
}
async function bumpGlobal(){
  const k = dayKey(); if(dayCounter.key !== k){ dayCounter.key = k; dayCounter.n = 0; } dayCounter.n++;
  const ctrl = new AbortController(); const t = setTimeout(()=>ctrl.abort(), 2000);
  try{
    await fetch(FB_DOCS+':commit?key='+encodeURIComponent(FB_KEY()), { method:'POST', signal:ctrl.signal, headers:{'content-type':'application/json'},
      body: JSON.stringify({ writes:[{ transform:{ document:'projects/asicoda/databases/(default)/documents/config/stats', fieldTransforms:[{ fieldPath:k, increment:{ integerValue:'1' } }] } }] }) });
  }catch(e){} finally { clearTimeout(t); }
}

/* per visitor (best effort, in memory).
   - Each browser has its own id (sent by the page), so many people behind one mobile-carrier IP do not block each other.
   - Only the user's question (fast step) counts against the daily allowance; the deep step belongs to the same question.
   - A much looser per-IP cap still stops abuse from one address. */
const hits = new Map();
function bucketFor(key, day){ let v = hits.get(key); if(!v || v.day !== day){ v = { day, n:0, nv:0, hour:[] }; hits.set(key, v); } return v; }
function visitorLimited(vid, ip, perDay, mode){
  const now = Date.now(), day = new Date().toISOString().slice(0,10);
  const vk = vid ? 'v:'+vid : 'i:'+ip;
  const v = bucketFor(vk, day), w = bucketFor('i:'+ip, day);
  v.hour = v.hour.filter(t=> now-t < 3600e3);
  const hourCap = RATE_PER_HOUR();
  if(mode==='vision' && v.nv >= perDay) return true;
  if(mode==='fast' && v.n >= perDay) return true;
  if(v.hour.length >= hourCap) return true;
  if(mode==='fast' && w.n >= perDay*12) return true;                  // shared IPs: allow plenty, block floods only
  if(mode==='fast'){ v.n++; w.n++; }
  if(mode==='vision'){ v.nv++; }
  v.hour.push(now);
  if(hits.size > 8000) hits.clear();
  return false;
}
const SMALL = /^(?:ا?لسلام عليكم|سلام|هلا|هلو|اهلا|أهلا|مرحبا|مرحبتين|صباح الخير|مساء الخير|شكرا|شكراً|تسلم|يعطيك العافيه|hi|hello|hey|thanks|ok|اوكي|تمام)[\s!.,؟?]*$/i;
const CACHE = new Map();   // normalised question -> { t, r }   (per warm instance; saves quota and gives instant answers)
const CACHE_MS = 6*3600e3;
const J = (code, obj) => ({ statusCode:code, headers:{ 'content-type':'application/json; charset=utf-8', 'cache-control':'no-store' }, body:JSON.stringify(obj) });

exports.handler = async (event) => {
  if(event.httpMethod === 'GET' && event.queryStringParameters && event.queryStringParameters.test){
    const out = [];
    for(const model of MODELS_FAST().concat(MODELS_DEEP())){
      try{
        const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent', { method:'POST', headers:{'content-type':'application/json','x-goog-api-key':KEY()}, body:JSON.stringify({ contents:[{role:'user',parts:[{text:'hi'}]}], generationConfig:{maxOutputTokens:5} }) });
        const j = await r.json().catch(()=>({}));
        out.push({ model, status:r.status, msg: r.ok ? 'OK' : String((j.error&&j.error.message)||'').slice(0,200) });
      }catch(e){ out.push({ model, status:0, msg:String(e.message).slice(0,200) }); }
    }
    // Google Search (grounding) is a separate feature with its own, tighter quota: test it on its own
    for(const model of MODELS_DEEP()){
      try{
        const r = await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent', { method:'POST', headers:{'content-type':'application/json','x-goog-api-key':KEY()}, body:JSON.stringify({ contents:[{role:'user',parts:[{text:'what is a split air conditioner'}]}], tools:[{ google_search:{} }], generationConfig:{ maxOutputTokens:20 } }) });
        const j = await r.json().catch(()=>({}));
        out.push({ model, feature:'google_search', status:r.status, msg: r.ok ? 'OK' : String((j.error&&j.error.message)||'').slice(0,200) });
      }catch(e){ out.push({ model, feature:'google_search', status:0, msg:String(e.message).slice(0,200) }); }
    }
    return J(200, { tests: out });
  }
  if(event.httpMethod === 'GET'){   // diagnostics: open the function URL in a browser (no secrets are shown)
    const c = await loadCfg();
    const names = Object.keys(process.env).filter(k=>!/^(AWS_|LAMBDA_|_|NODE|PATH|LANG|TZ$|PWD|HOME|SHLVL|LD_|XDG|NETLIFY_|DENO|CONTEXT|SITE_|URL$|DEPLOY|BRANCH|REPOSITORY|HEAD|COMMIT|BUILD|REVIEW|PULL|INCOMING|GIT)/.test(k)).map(k=>({ name:k, len:k.length, codes:Array.from(k).filter(ch=>ch.charCodeAt(0)>126||ch===' ').length }));
    return J(200, { function:'ok', keySet: !!KEY(), keyLength: KEY().length, enabledInAdmin: c.enabled, dailyCap:c.dailyCap, freePerDay:c.freePerDay, otherEnvNames: names, totalEnvCount: Object.keys(process.env).length });
  }
  if(event.httpMethod !== 'POST') return J(405, { status:'error', message:'method' });
  const h = event.headers || {};
  const origin = h.origin || h.Origin || '';
  if(origin){
    let ok = false;
    try{ const oh = new URL(origin).host; ok = oh === (h.host || h.Host) || (process.env.ALLOWED_ORIGINS||'').split(',').map(s=>s.trim()).filter(Boolean).some(a=>{ try{ return new URL(a).host === oh; }catch(e){ return false; } }); }catch(e){}
    if(!ok) return J(403, { status:'error', message:'origin' });
  }
  if(!KEY()) return J(200, { status:'error', message:'not_configured' });

  let body; try{ body = JSON.parse(event.body || '{}'); }catch(e){ return J(400, { status:'error', message:'json' }); }
  const image = (typeof body.image === 'string' && body.image.length < 900000 && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(body.image)) ? body.image : null;
  const mode = (body.mode === 'vision' && image) ? 'vision' : (body.mode === 'deep' ? 'deep' : 'fast');
  const retry = body.retry === true;
  const general = body.general === true;
  const rejected = (Array.isArray(body.rejected) ? body.rejected : []).map(x=>String(x).replace(/[^0-9]/g,'')).filter(x=>x.length>=4 && x.length<=12).slice(0,12);
  const queryText = typeof body.query === 'string' ? body.query.trim().slice(0,300) : '';
  const hist = (Array.isArray(body.messages) ? body.messages : []).slice(-6)
    .filter(m=>m && (m.role==='user' || m.role==='assistant') && typeof m.content==='string' && m.content.trim())
    .map(m=>({ role:m.role, content:m.content.trim().slice(0,400) }));
  while(hist.length && hist[0].role !== 'user') hist.shift();
  if(mode !== 'vision' && (!hist.length || hist[hist.length-1].role !== 'user')) return J(400, { status:'error', message:'messages' });

  const lastText = hist.length ? hist[hist.length-1].content : '';
  if(mode !== 'vision' && hist.length === 1 && (SMALL.test(norm(lastText).replace(/^ال/,'ال')) || SMALL.test(lastText.trim())))
    return J(200, { mode, status:'need_info', question:'أهلًا بك 👋 اكتب اسم بضاعتك أو وصفها (مثلًا: مكيف سبلت، هاتف محمول، ملابس أطفال) وأقترح لك أقرب بند.' });
  const ckey = (mode !== 'vision' && !retry && !rejected.length && hist.length === 1) ? norm(lastText) + '|' + mode : '';
  if(ckey){ const c = CACHE.get(ckey); if(c && Date.now()-c.t < CACHE_MS) return J(200, Object.assign({ mode, cached:true }, c.r)); }

  const cfg = await loadCfg();
  if(!cfg.enabled) return J(200, { status:'error', message:'disabled' });
  const ip = h['x-nf-client-connection-ip'] || (h['x-forwarded-for']||'').split(',')[0].trim() || 'unknown';
  const vid = String((body && body.vid) || '').replace(/[^A-Za-z0-9_-]/g,'').slice(0,40);
  const lmode = retry ? 'fast' : mode;                         // a "search again" counts as one more question
  if(visitorLimited(vid, ip, cfg.freePerDay, lmode)) return J(200, { status:'limit', reason:'visitor' });
  if(lmode === 'fast'){                                         // the admin cap counts user questions (the deep step belongs to the same question)
    if(await globalCount() >= cfg.dailyCap) return J(200, { status:'limit', reason:'daily' });
    await bumpGlobal();
  }

  if(mode === 'vision'){
    try{
      const userNote = (lastText || '').slice(0,200);
      const v = await describeImage(image, userNote, 22000);
      if(!v.text) return J(200, { mode, status:'unsure', note:'vision_empty' });
      return J(200, { mode, status:'vision', product:v.text, usedWeb:v.usedWeb });
    }catch(e){
      console.error('hs-bot vision failed:', e && e.message);
      if(e && e.name === 'AbortError') return J(200, { status:'unsure', timedOut:true, mode });
      if(e && (e.status === 429 || e.status === 503)) return J(200, { status:'limit', reason:'provider', mode, detail:String(e.message||'').slice(0,300) });
      return J(200, { status:'error', detail:String((e&&e.message)||'').slice(0,300), message:'failed', mode });
    }
  }
  try{
    const r = await classify(mode, hist, mode==='deep' ? 24000 : 8500, { exclude:new Set(rejected), query:queryText, retry, general, knowledge:cfg.knowledge });
    if(ckey && (r.status === 'answer' || r.status === 'unsure' || r.status === 'reply') && !r.timedOut && !(r.status==='reply' && r.usedWeb)){ if(CACHE.size > 500) CACHE.clear(); CACHE.set(ckey, { t:Date.now(), r }); }
    return J(200, Object.assign({ mode }, r));
  }catch(e){
    console.error('hs-bot failed:', e && e.message);
    if(e && e.name === 'AbortError') return J(200, { status:'unsure', timedOut:true, mode });
    if(e && (e.status === 429 || e.status === 503)) return J(200, { status:'limit', reason:'provider', mode, detail:String(e.message||'').slice(0,300) });
    return J(200, { status:'error', detail:String((e&&e.message)||'').slice(0,300), message: e && (e.status===401 || e.status===403 || /API key/i.test(e.message||'')) ? 'bad_key' : 'failed', mode });
  }
};
exports._internal = { searchTable, fmtRow, finalize, norm, tokens, TABLE, classify, describeImage };
