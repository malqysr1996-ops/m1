'use strict';
/* iraqtariff.com — public tariff API for partner companies.
   URL:  /api/tariff?hs=87032310      one item (or every item starting with a prefix of >= 4 digits)
         /api/tariff?q=سيارة          search by goods description
         /api/usage                   the caller's own usage (not counted)
         /api/health                  no key needed
   Auth: header  x-api-key: <key>   (or  Authorization: Bearer <key>,  or ?key=)
   Keys are created / suspended / deleted from the admin panel and live in Firestore:
     apiKeys/{sha256(key)}        {name, active, dailyLimit, expiresAt, note, createdAt, used:{day,n}, total, lastAt}
     apiKeySecrets/{sha256(key)}  {key}   (admin only - never read here)
   The key itself is never stored in apiKeys, only its SHA-256, which is also the document id. */

const crypto = require('crypto');
const TABLE = require('./api-tariff.json');   // [hs, desc, unit, min, max, rate, prohibited, ctx]

const FB_KEY = () => process.env.FIREBASE_API_KEY || 'AIzaSyCI5Pj7C6nXozklApr5QPYmKqbMSKiO-oY';
const FB_DOCS = () => process.env.FS_BASE || 'https://firestore.googleapis.com/v1/projects/asicoda/databases/(default)/documents';
const AUTH_URL = () => process.env.AUTH_URL || ('https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=' + encodeURIComponent(FB_KEY()));
const PER_MIN = () => parseInt(process.env.API_PER_MIN || '60', 10);
const KEY_TTL = 30 * 1000, CFG_TTL = 5 * 60 * 1000;

/* ---------------- text search (same engine as the HS assistant) ---------------- */
const STOP = new Set(['من','في','علي','الي','او','و','ذات','نوع','غير','غيرها','اخري','اخر','مع','بدون','عن','هذا','هذه','للاستعمال','مخصص','خاص','مصنوع','مصنوعه','مصنوعة']);
function norm(s){
  return String(s||'').toLowerCase()
    .replace(/[ً-ٰٟـ]/g,'')
    .replace(/[أإآٱ]/g,'ا').replace(/ى/g,'ي').replace(/ؤ/g,'و').replace(/ئ/g,'ي').replace(/ة/g,'ه')
    .replace(/[٠-٩]/g, d=>String(d.charCodeAt(0)-0x0660))
    .replace(/[^\p{L}\p{N}\s]/gu,' ').replace(/\s+/g,' ').trim();
}
function stem(t){
  t = t.replace(/^(وال|بال|كال|فال|لل|ال)/,'');
  if(t.length > 4) t = t.replace(/(ات|ون|ين|ان|ها|ه|ي)$/,'');
  return t;
}
function tokens(s, keepStop){
  return norm(s).split(' ').filter(w=>w.length>=2).map(stem).filter(w=>w.length>=2 && (keepStop || !STOP.has(w)));
}
let DOCS = null, DF = null;
function buildIndex(){
  if(DOCS) return;
  DOCS = TABLE.map(r => { const t = r[1]+' '+(r[7]||''); return { set:new Set(tokens(t, true)), text:norm(t) }; });
  DF = new Map();
  DOCS.forEach(d => d.set.forEach(t => DF.set(t,(DF.get(t)||0)+1)));
}
const idf = t => Math.log(1 + TABLE.length/(1+(DF.get(t)||0)));
function searchTable(query, limit){
  buildIndex();
  const q = tokens(query);
  if(!q.length) return [];
  const scored = [];
  for(let i=0;i<TABLE.length;i++){
    const d = DOCS[i]; let s = 0, hit = 0;
    for(const t of q){
      if(d.set.has(t)){ s += idf(t); hit++; }
      else if(t.length >= 3 && d.text.includes(t)){ s += idf(t)*0.6; hit++; }
    }
    if(!hit) continue;
    s += (hit/q.length) * 2;
    scored.push([s,i]);
  }
  scored.sort((a,b)=> b[0]-a[0] || a[1]-b[1]);
  return scored.slice(0,limit).map(x=>x[1]);
}

/* ---------------- Firestore REST helpers ---------------- */
function decode(v){
  if(!v || typeof v !== 'object') return null;
  if('stringValue' in v) return v.stringValue;
  if('integerValue' in v) return Number(v.integerValue);
  if('doubleValue' in v) return Number(v.doubleValue);
  if('booleanValue' in v) return v.booleanValue;
  if('nullValue' in v) return null;
  if('timestampValue' in v) return Date.parse(v.timestampValue);
  if('mapValue' in v){ const o = {}, f = v.mapValue.fields || {}; for(const k in f) o[k] = decode(f[k]); return o; }
  if('arrayValue' in v) return (v.arrayValue.values || []).map(decode);
  return null;
}
const decodeDoc = d => { const o = {}, f = (d && d.fields) || {}; for(const k in f) o[k] = decode(f[k]); return o; };
async function tfetch(url, opt, ms){
  const ctrl = new AbortController(); const t = setTimeout(()=>ctrl.abort(), ms || 6000);
  try{ return await fetch(url, Object.assign({ signal:ctrl.signal }, opt||{})); } finally { clearTimeout(t); }
}
async function fsGet(path){           // -> {status, data}
  const r = await tfetch(FB_DOCS()+'/'+path+'?key='+encodeURIComponent(FB_KEY()));
  if(r.status === 404) return { status:404, data:null };
  if(!r.ok) return { status:r.status, data:null };
  return { status:200, data:decodeDoc(await r.json()) };
}
let TOKEN = { v:'', exp:0 };
async function idToken(){
  if(TOKEN.v && Date.now() < TOKEN.exp) return TOKEN.v;
  const r = await tfetch(AUTH_URL(), { method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({ returnSecureToken:true }) });
  if(!r.ok) throw new Error('auth '+r.status);
  const j = await r.json();
  TOKEN = { v:j.idToken, exp: Date.now() + Math.max(60, (parseInt(j.expiresIn,10)||3600) - 120) * 1000 };
  return TOKEN.v;
}
const intV = n => ({ integerValue:String(Math.trunc(n)) });
async function countUse(hash, doc, today){
  const name = 'projects/asicoda/databases/(default)/documents/apiKeys/'+hash;
  const base = FB_DOCS().replace(/\/documents$/, '');
  const sameDay = doc.used && doc.used.day === today;
  const write = sameDay ? {
    update:{ name, fields:{ lastAt:intV(Date.now()) } }, updateMask:{ fieldPaths:['lastAt'] },
    updateTransforms:[ { fieldPath:'used.n', increment:intV(1) }, { fieldPath:'total', increment:intV(1) } ],
    currentDocument:{ exists:true }
  } : {
    update:{ name, fields:{ lastAt:intV(Date.now()), used:{ mapValue:{ fields:{ day:{ stringValue:today }, n:intV(1) } } } } },
    updateMask:{ fieldPaths:['lastAt','used'] },
    updateTransforms:[ { fieldPath:'total', increment:intV(1) } ],
    currentDocument:{ exists:true }
  };
  const tok = await idToken();
  const r = await tfetch(base+'/documents:commit', { method:'POST', headers:{'content-type':'application/json', authorization:'Bearer '+tok}, body:JSON.stringify({ writes:[write] }) });
  if(!r.ok) throw new Error('commit '+r.status);
}

/* ---------------- config (rates, overrides, protection), cached ---------------- */
let CFG = null, CFG_AT = 0;
const DEFAULT_RATES = { '5%':{tax:1,export:0.5}, '10%':{tax:3,export:0.5}, '15%':{tax:3,export:0.5}, '30%':{tax:3,export:0.5} };
async function loadCfg(){
  if(CFG && Date.now() - CFG_AT < CFG_TTL) return CFG;
  const cfg = { rates:DEFAULT_RATES, exportDefault:0.5, protection:{}, over:new Map() };
  try{
    const [rr, st, pp] = await Promise.all([ fsGet('config/rateRules'), fsGet('config/settings'), fsGet('config/productProtection') ]);
    if(rr.data && Object.keys(rr.data).length) cfg.rates = rr.data;
    if(st.data && st.data.exportDefault != null) cfg.exportDefault = +st.data.exportDefault;
    if(pp.data && pp.data.items) cfg.protection = pp.data.items;
    let tok = '';
    for(let i=0;i<40;i++){
      const r = await tfetch(FB_DOCS()+'/tariffOverrides?pageSize=300&key='+encodeURIComponent(FB_KEY())+(tok?'&pageToken='+encodeURIComponent(tok):''));
      if(!r.ok) break;
      const j = await r.json();
      (j.documents||[]).forEach(d => { const o = decodeDoc(d); if(o.row && o.row[0]) cfg.over.set(String(o.row[0]), o.row); });
      tok = j.nextPageToken; if(!tok) break;
    }
    CFG = cfg; CFG_AT = Date.now();
  }catch(e){ if(CFG) return CFG; CFG = cfg; CFG_AT = Date.now() - CFG_TTL + 20000; }   // keep serving defaults, retry in 20s
  return CFG;
}
function item(i, cfg){
  let r = TABLE[i];
  const ov = cfg.over.get(r[0]);
  if(ov) r = [ r[0], String(ov[1]||r[1]).replace(/^[\s\-–]+/,''), ov[2]||'', ov[3], ov[4], ov[5]||'', r[6], r[7], r[8] ];
  const rate = r[5] || '0%';
  const rule = cfg.rates[rate];
  const customs = parseFloat(rate) || 0;
  const prot = +((cfg.protection[r[0]] && cfg.protection[r[0]].pct) || 0);
  const tax = (r[8] != null && isFinite(+r[8])) ? +r[8] : (rule ? +rule.tax : 0);
  const exp = rule ? +rule.export : cfg.exportDefault;
  const mn = r[3] != null ? r[3] : null, mx = r[4] != null ? r[4] : null;
  const avg = (mn!=null && mx!=null) ? +((mn+mx)/2).toFixed(4) : (mn!=null ? mn : (mx!=null ? mx : null));
  const out = { hs:r[0], description:r[1], unit:r[2]||null, customs_pct:customs, protection_pct:prot, tax_pct:tax, export_pct:exp,
    total_pct:+(customs+prot+tax+exp).toFixed(2), min_value:mn, max_value:mx, avg_value:avg, prohibited:!!r[6] };
  if(r[7]) out.context = r[7];
  return out;
}

/* ---------------- request handling ---------------- */
const H = { 'content-type':'application/json; charset=utf-8', 'access-control-allow-origin':'*', 'access-control-allow-headers':'x-api-key, authorization, content-type', 'access-control-allow-methods':'GET, OPTIONS', 'cache-control':'no-store' };
const send = (code, body, extra) => ({ statusCode:code, headers:Object.assign({}, H, extra||{}), body:JSON.stringify(body) });
const fail = (code, err, msg, extra) => send(code, { error:{ code:err, message:msg } }, extra);

const KEYS = new Map();               // hash -> { doc, at }
const MIN = new Map();                // hash -> { m, n }
const BAD = new Map();                // ip -> { m, n }
const today = () => new Date(Date.now() + 3*3600*1000).toISOString().slice(0,10);   // Baghdad day
const minuteNow = () => Math.floor(Date.now()/60000);
function bump(map, k, limit){ const m = minuteNow(); let v = map.get(k); if(!v || v.m !== m){ v = { m, n:0 }; map.set(k, v); if(map.size > 2000) map.clear(); } v.n++; return v.n > limit; }

async function keyDoc(hash){
  const c = KEYS.get(hash);
  if(c && Date.now() - c.at < KEY_TTL) return c;
  const r = await fsGet('apiKeys/'+hash);
  if(r.status !== 200 && r.status !== 404) throw new Error('fs '+r.status);
  const e = { doc:r.data, at:Date.now() };
  KEYS.set(hash, e); if(KEYS.size > 500) KEYS.clear();
  return e;
}
const clampInt = (v, d, lo, hi) => { v = parseInt(v, 10); if(!(v >= lo)) v = d; return Math.min(v, hi); };
const digits = s => String(s||'').replace(/[٠-٩]/g, d=>String(d.charCodeAt(0)-0x0660)).replace(/\D/g,'');

exports.handler = async (event) => {
  const method = event.httpMethod || 'GET';
  if(method === 'OPTIONS') return { statusCode:204, headers:H, body:'' };
  if(method !== 'GET') return fail(405, 'method_not_allowed', 'استخدم GET فقط.');
  const q = event.queryStringParameters || {};
  const route = String(event.path||'').replace(/\/+$/,'').split('/').pop();

  if(route === 'health'){ return send(200, { status:'ok', items:TABLE.length }); }

  const hdr = event.headers || {}; const g = n => hdr[n] || hdr[n.toLowerCase()] || '';
  let key = String(g('x-api-key') || '').trim();
  if(!key){ const a = String(g('authorization')||''); if(/^bearer\s+/i.test(a)) key = a.replace(/^bearer\s+/i,'').trim(); }
  if(!key) key = String(q.key||'').trim();
  const ip = String(g('x-nf-client-connection-ip') || g('x-forwarded-for') || 'x').split(',')[0].trim();
  if(!key || key.length < 20 || key.length > 120){
    if(bump(BAD, ip, 30)) return fail(429, 'too_many_attempts', 'محاولات كثيرة، أعد المحاولة بعد دقيقة.', { 'retry-after':'60' });
    return fail(401, 'missing_key', 'مفتاح الوصول مطلوب. أرسله في الترويسة x-api-key.');
  }
  const hash = crypto.createHash('sha256').update(key).digest('hex');
  let e;
  try{ e = await keyDoc(hash); }catch(err){ return fail(503, 'unavailable', 'الخدمة غير متاحة مؤقتاً، حاول بعد قليل.'); }
  const doc = e.doc;
  if(!doc){
    if(bump(BAD, ip, 30)) return fail(429, 'too_many_attempts', 'محاولات كثيرة، أعد المحاولة بعد دقيقة.', { 'retry-after':'60' });
    return fail(401, 'invalid_key', 'مفتاح الوصول غير صحيح.');
  }
  if(doc.active === false) return fail(403, 'key_suspended', 'هذا المفتاح موقوف. تواصل مع مزوّد الخدمة.');
  if(doc.expiresAt && Date.now() > +doc.expiresAt) return fail(403, 'key_expired', 'انتهت صلاحية هذا المفتاح.');

  const day = today();
  const used = (doc.used && doc.used.day === day) ? (doc.used.n || 0) : 0;
  const limit = +doc.dailyLimit || 0;

  if(route === 'usage'){
    return send(200, { data:{ company:doc.name || null, active:true, used_today:used, daily_limit:limit || null,
      remaining_today: limit ? Math.max(0, limit - used) : null, total_requests:doc.total || 0, expires_at: doc.expiresAt ? new Date(+doc.expiresAt).toISOString() : null } });
  }
  if(route !== 'tariff' && route !== 'search') return fail(404, 'unknown_endpoint', 'المسار غير معروف. المتاح: /api/tariff و /api/usage');

  if(limit && used >= limit) return fail(429, 'daily_limit_reached', 'تم بلوغ الحد اليومي للاستعلامات ('+limit+'). يتجدد عند منتصف الليل بتوقيت بغداد.', { 'retry-after':'3600' });
  if(bump(MIN, hash, PER_MIN())) return fail(429, 'rate_limited', 'عدد الطلبات بالدقيقة كبير، خفّف الوتيرة.', { 'retry-after':'30' });

  const cfg = await loadCfg();
  const hs = digits(q.hs || q.code || ''), text = String(q.q || q.query || '').trim();
  let out;
  if(hs){
    if(hs.length < 4) return fail(400, 'bad_request', 'رقم البند يجب أن يكون 4 أرقام على الأقل.');
    const lim = clampInt(q.limit, 20, 1, 50);
    const hits = [];
    for(let i=0;i<TABLE.length;i++){ if(TABLE[i][0].startsWith(hs)) hits.push(i); }
    if(!hits.length) return fail(404, 'not_found', 'لا يوجد بند يطابق هذا الرقم.');
    if(hits.length === 1) out = { data:item(hits[0], cfg) };
    else out = { data:hits.slice(0,lim).map(i=>item(i,cfg)), count:Math.min(hits.length,lim), total_matches:hits.length };
  } else if(text){
    if(text.length < 2 || text.length > 120) return fail(400, 'bad_request', 'نص البحث بين 2 و120 حرفاً.');
    const lim = clampInt(q.limit, 10, 1, 25);
    const idx = searchTable(text, lim);
    out = { data:idx.map(i=>item(i,cfg)), count:idx.length };
  } else return fail(400, 'bad_request', 'أرسل hs=رقم البند أو q=وصف البضاعة.');

  try{ await countUse(hash, doc, day); }catch(err){ console.error('count failed', err && err.message); }
  if(doc.used && doc.used.day === day) doc.used.n = (doc.used.n || 0) + 1; else doc.used = { day, n:1 };
  doc.total = (doc.total || 0) + 1;
  out.meta = { company:doc.name || null, used_today:doc.used.n, daily_limit:limit || null };
  return send(200, out);
};
