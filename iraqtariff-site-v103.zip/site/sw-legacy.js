/* Served ONLY on the old address (iraqtariff.netlify.app) in place of /sw.js.
   It removes the old service worker + caches from visitors' browsers and reloads the page,
   so they follow the 301 to the new domain instead of getting stuck on a stale worker. */
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil((async () => {
  try { const keys = await caches.keys(); await Promise.all(keys.map(k => caches.delete(k))); } catch (err) {}
  try { await self.registration.unregister(); } catch (err) {}
  try { const cs = await self.clients.matchAll({ type: 'window' }); cs.forEach(c => { try { c.navigate(c.url); } catch (err) {} }); } catch (err) {}
})()));
