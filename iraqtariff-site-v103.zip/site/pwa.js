/* PWA: service worker registration + "install the site" prompt (Android / desktop Chrome & Edge) + iPhone instructions */
(function(){
  'use strict';
  if('serviceWorker' in navigator){ window.addEventListener('load', function(){ navigator.serviceWorker.register('/sw.js').catch(function(){}); }); }

  var LS = { get:function(k){ try{ return localStorage.getItem(k); }catch(e){ return null; } }, set:function(k,v){ try{ localStorage.setItem(k,v); }catch(e){} } };
  var DAY = 86400000, now = Date.now();
  /* usage counters: queued locally, and sent to the database by the home page (it owns the Firebase connection) */
  function stat(field){
    try{ var q = JSON.parse(LS.get('pwaPending') || '{}'); q[field] = (q[field] || 0) + 1; LS.set('pwaPending', JSON.stringify(q)); }catch(e){}
    try{ window.dispatchEvent(new CustomEvent('pwa-flush')); }catch(e){}
  }
  var standalone = (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
  if(standalone){                                                                // running as an installed app: count it, never show the prompt
    if(LS.get('pwaInstallCounted') !== '1'){ LS.set('pwaInstallCounted','1'); LS.set('pwaInstalled','1'); stat('pwaInstalls'); }   // covers iPhone + installs we did not see
    var today = new Date().toISOString().slice(0,10);
    if(LS.get('pwaOpenDay') !== today){ LS.set('pwaOpenDay', today); stat('pwaOpens'); }   // once per day per device = active app users
    return;
  }
  if(LS.get('pwaInstalled') === '1') return;                                    // installed earlier: do not bother the visitor

  var ua = navigator.userAgent || '';
  var isIOS = /iphone|ipad|ipod/i.test(ua) || (/Macintosh/i.test(ua) && navigator.maxTouchPoints > 1);
  var deferred = null, bar = null, shown = false;

  var css = '.pwabar{position:fixed;z-index:76;left:12px;right:12px;bottom:calc(12px + env(safe-area-inset-bottom,0px));max-width:460px;margin:0 auto;background:#fff;border:1.5px solid #D9A928;border-radius:20px;box-shadow:0 18px 40px rgba(0,0,0,.35);padding:14px 14px 12px;direction:rtl;font-family:Tajawal,Tahoma,Arial,sans-serif;animation:pwaIn .45s cubic-bezier(.2,.8,.2,1) both;color:#2A1118}'
   + '@keyframes pwaIn{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:none}}'
   + '.pwabar .r{display:flex;gap:12px;align-items:center}.pwabar img{width:48px;height:48px;border-radius:12px;flex:none;box-shadow:0 3px 10px rgba(0,0,0,.2)}'
   + '.pwabar b{display:block;font-size:15px;color:#5B1A2B;line-height:1.5}.pwabar p{margin:2px 0 0;font-size:12.5px;line-height:1.7;color:#6B5A5E}'
   + '.pwabar .a{display:flex;gap:8px;margin-top:12px}.pwabar button{flex:1;font-family:inherit;font-weight:800;font-size:14px;border-radius:12px;padding:11px 10px;cursor:pointer;border:1.5px solid #E9E0DD;background:#fff;color:#5B1A2B}'
   + '.pwabar button.go{background:linear-gradient(135deg,#EBC24F,#D9A928 55%,#C8961F);border-color:transparent;box-shadow:0 6px 14px rgba(217,169,40,.45)}'
   + '.pwabar .x{position:absolute;top:6px;left:10px;border:none;background:none;font-size:20px;color:#8a7a7c;padding:4px;flex:none;width:auto;cursor:pointer}'
   + '.pwabar .sh{display:inline-block;vertical-align:-4px;width:18px;height:18px}'
   + '.pwalink{background:none;border:none;color:inherit;font:inherit;cursor:pointer;text-decoration:underline;padding:0}'
   + '@media(prefers-reduced-motion:reduce){.pwabar{animation:none}}';
  var st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);

  function close(remember){ if(bar){ bar.remove(); bar = null; } if(remember){ LS.set('pwaDismissAt', String(Date.now())); stat('pwaLater'); } }
  function recentlyDismissed(){ var t = +LS.get('pwaDismissAt') || 0; return (now - t) < DAY; }          // pressed "later": ask again after 24 hours

  function build(ios){
    var el = document.createElement('div'); el.className = 'pwabar'; el.setAttribute('role','dialog'); el.setAttribute('aria-label','تثبيت الموقع');
    var shareSvg = '<svg class="sh" viewBox="0 0 24 24" fill="none" stroke="#2f80d8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 16V4M8 8l4-4 4 4"/><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7"/></svg>';
    el.innerHTML = '<button class="x" type="button" aria-label="إغلاق">×</button><div class="r"><img src="/favicon-192.png" alt=""><div><b>ثبّت حاسبة التعرفة على جهازك</b><p>'
      + (ios === 'manual' ? 'من قائمة المتصفح (⋮ أو زر المشاركة) اختر <b style="display:inline;font-size:12.5px">«تثبيت التطبيق»</b> أو <b style="display:inline;font-size:12.5px">«إضافة إلى الشاشة الرئيسية»</b>.' : ios ? 'اضغط زر المشاركة ' + shareSvg + ' أسفل الشاشة، ثم اختر <b style="display:inline;font-size:12.5px">«إضافة إلى الشاشة الرئيسية»</b>.' : 'وصول أسرع بضغطة واحدة، ويفتح بملء الشاشة مثل التطبيقات.')
      + '</p></div></div><div class="a">' + (ios ? '<button type="button" class="go" data-a="ok">فهمت</button>' : '<button type="button" class="go" data-a="install">تثبيت الآن</button><button type="button" data-a="later">لاحقًا</button>') + '</div>';
    el.addEventListener('click', function(e){
      var b = e.target.closest('button'); if(!b) return;
      if(b.classList.contains('x') || b.dataset.a === 'later' || b.dataset.a === 'ok') return close(true);
      if(b.dataset.a === 'install') doInstall();
    });
    return el;
  }
  function show(ios){
    if(shown || bar) return; shown = true;
    bar = build(ios); document.body.appendChild(bar); stat('pwaPrompts');
    setTimeout(function(){ if(bar) close(false); }, 25000);                       // fades away by itself; will not nag on every visit
  }
  function doInstall(){
    if(!deferred) return;
    var d = deferred; deferred = null; close(false);
    try{ d.prompt(); d.userChoice.then(function(c){ if(c && c.outcome === 'accepted'){ LS.set('pwaInstalled','1'); stat('pwaAccepts'); } else { LS.set('pwaDismissAt', String(Date.now())); stat('pwaLater'); } }); }catch(e){}
  }

  window.addEventListener('beforeinstallprompt', function(e){
    e.preventDefault(); deferred = e;
    addFooterLink();
    if(!recentlyDismissed()) setTimeout(function(){ if(deferred) show(false); }, Math.max(0, 3500 - (Date.now() - now)));
  });
  window.addEventListener('appinstalled', function(){ LS.set('pwaInstalled','1'); if(LS.get('pwaInstallCounted') !== '1'){ LS.set('pwaInstallCounted','1'); stat('pwaInstalls'); } deferred = null; close(false); var f = document.getElementById('pwaFooterLink'); if(f) f.remove(); });

  addFooterLink();                                                              // the footer link is on every page, on every device
  if(isIOS){
    if(!recentlyDismissed()) setTimeout(function(){ show(true); }, 4000);
  }

  /* a permanent small link in the footer, so the visitor can install later if he dismissed the banner */
  function addFooterLink(){
    if(document.getElementById('pwaFooterLink')) return;
    var host = document.querySelector('footer'); if(!host) return;
    var d = document.createElement('div'); d.id = 'pwaFooterLink'; d.style.cssText = 'margin:10px 0 2px;font-size:12.5px;';
    var sw = document.getElementById('stickyWa'); if(sw){ d.style.marginBottom = (Math.ceil(sw.getBoundingClientRect().height) + 24) + 'px'; }   // keep the link clear of the sticky WhatsApp bar
    var b = document.createElement('button'); b.type = 'button'; b.className = 'pwalink'; b.textContent = '📲 ثبّت الموقع كتطبيق على جهازك';
    b.addEventListener('click', function(){ if(deferred) doInstall(); else { shown = false; close(false); show(isIOS ? true : 'manual'); } });
    d.appendChild(b); var c = host.querySelector('.fcontact'); if(c && c.parentNode) c.parentNode.insertBefore(d, c.nextSibling); else host.appendChild(d);
  }
})();
