/* مفاتيح الواجهة العامة لمشروع Firebase: asycuda-training (ليست سرّية). */
window.FB_CONFIG = {
  apiKey: "AIzaSyAlkEbK4fur16dr0uC0gvytN--UfBYrkPI",
  authDomain: "asycuda-training.firebaseapp.com",
  projectId: "asycuda-training",
  storageBucket: "asycuda-training.firebasestorage.app",
  messagingSenderId: "20127864341",
  appId: "1:20127864341:web:199e53a1fc2441359fa01c"
};
