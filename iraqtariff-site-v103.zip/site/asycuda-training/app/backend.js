/* الربط مع Firebase (تسجيل + اشتراكات). الدخول: رقم الهاتف + كلمة سر. */
(function(){
var C=window.FB_CONFIG||{},V='10.12.2',B='https://www.gstatic.com/firebasejs/'+V+'/';
var BE=window.BE={on:!!(C.apiKey&&C.projectId)};
if(!BE.on)return;
var A,F,auth,db,M={};
function mail(p){return '964'+p+'@iraqtariff.app'}
function msg(e){var c=(e&&e.code)||'';
 if(/email-already-in-use/.test(c))return 'هذا الرقم مسجّل من قبل، استخدم «دخول».';
 if(/wrong-password|invalid-credential|user-not-found|invalid-login/.test(c))return 'الرقم أو كلمة السر غير صحيحة.';
 if(/weak-password/.test(c))return 'كلمة السر ضعيفة (6 أحرف على الأقل).';
 if(/too-many/.test(c))return 'محاولات كثيرة، جرّب بعد شوي.';
 if(/network/.test(c))return 'ما كو اتصال بالإنترنت.';
 if(/permission/.test(c))return 'ما عندك صلاحية.';
 return 'صار خطأ، حاول مرة ثانية.'}
BE.msg=msg;
BE.ready=Promise.all([import(B+'firebase-app.js'),import(B+'firebase-auth.js'),import(B+'firebase-firestore.js')]).then(function(m){
 A=m[0];M.auth=m[1];F=m[2];var app=A.initializeApp(C);auth=M.auth.getAuth(app);db=F.getFirestore(app)});
async function profile(u){
 var d=await F.getDoc(F.doc(db,'users',u.uid)),adm=false;
 try{adm=(await F.getDoc(F.doc(db,'admins',u.uid))).exists()}catch(e){}
 var x=d.exists()?d.data():{};return {uid:u.uid,p:x.phone||'',e:+x.subUntil||0,admin:adm}}
BE.signUp=async function(p,pw){await BE.ready;
 var c=await M.auth.createUserWithEmailAndPassword(auth,mail(p),pw);
 await F.setDoc(F.doc(db,'users',c.user.uid),{phone:p,createdAt:Date.now(),subUntil:0});
 return profile(c.user)};
BE.signIn=async function(p,pw){await BE.ready;
 var c=await M.auth.signInWithEmailAndPassword(auth,mail(p),pw);return profile(c.user)};
BE.signOut=async function(){await BE.ready;return M.auth.signOut(auth)};
BE.restore=function(cb){BE.ready.then(function(){M.auth.onAuthStateChanged(auth,async function(u){cb(u?await profile(u):null)})})};
BE.list=async function(){await BE.ready;
 var s=await F.getDocs(F.collection(db,'users'));
 return s.docs.map(function(d){var x=d.data();return {uid:d.id,p:x.phone,e:+x.subUntil||0}}).sort(function(a,b){return b.e-a.e})};
BE.setExp=async function(uid,e){await BE.ready;return F.updateDoc(F.doc(db,'users',uid),{subUntil:e})};
BE.token=async function(){await BE.ready;return auth.currentUser?auth.currentUser.getIdToken():null};
BE.feedback=async function(o){await BE.ready;if(!auth.currentUser)return;var id='u_'+auth.currentUser.uid+'_'+Date.now();
 return F.setDoc(F.doc(db,'feedback',id),{uid:auth.currentUser.uid,kind:'user',q:String(o.q).slice(0,1500),a:String(o.a).slice(0,4000),v:o.v,at:Date.now()})};
BE.fbList=async function(){await BE.ready;var s=await F.getDocs(F.query(F.collection(db,'feedback'),F.orderBy('at','desc'),F.limit(40)));
 return s.docs.map(function(d){var x=d.data();x.id=d.id;return x})};
BE.fbDel=async function(id){await BE.ready;return F.deleteDoc(F.doc(db,'feedback',id))};
BE.kbAdd=async function(q,a){await BE.ready;return F.addDoc(F.collection(db,'kb'),{q:q,a:a,ok:true,at:Date.now()})};
})();
