/* رقم الإجراء الموحد — محاكي تدريبي */
(function(S){
var UP=[];try{UP=JSON.parse(localStorage.getItem('sim_uprocs')||'[]')}catch(e){}
window.UPROCS=UP;
function save(){try{localStorage.setItem('sim_uprocs',JSON.stringify(UP))}catch(e){}}
function today(){var d=new Date();return ('0'+d.getDate()).slice(-2)+'/'+('0'+(d.getMonth()+1)).slice(-2)+'/'+d.getFullYear()}
function fakeCo(v){var n=0;for(var i=0;i<v.length;i++)n=(n*31+v.charCodeAt(i))%9973;var c=S.fakeCompanies[n%S.fakeCompanies.length];return c+'\nTraining Company '+v.slice(-3)+'\nالعراق - بغداد - عنوان تدريبي'}
function nextSeq(){var s,t=0;do{s=1000000+Math.floor(Math.random()*9000000);t++}while(t<50&&UP.some(function(u){return +u.no.slice(3)===s}));return s}
(function(){var s=document.createElement('style');s.textContent='.usheet{position:relative;width:900px;height:720px;margin:0 0 0 auto;background:#fff;font:11px Tahoma;direction:rtl}.usheet .ub{position:absolute;font:700 11px Tahoma;white-space:nowrap}.usheet .ui{position:absolute;border:1px solid #9aa0b0;background:#ececf2;font:700 11px Tahoma;direction:ltr;text-align:right;padding:2px 4px;outline:0;height:20px}.usheet .ui:focus{background:#dcd7f7}.usheet textarea.ui{height:82px;resize:none;direction:rtl;font-size:10px;line-height:1.25}.usheet .ubox{position:absolute;border:1.5px solid #14146e}.usheet .ucap{position:absolute;top:-10px;right:10px;background:#fff;padding:0 3px;color:#14146e;font:700 10px Tahoma}.usheet .uck{position:absolute;width:11px;height:11px;border:1px solid #444;background:#fff;font:700 10px Arial;line-height:10px;text-align:center}.usheet table{border-collapse:collapse}.usheet td,.usheet th{border:1px solid #888;font:11px Arial;padding:1px 4px;background:#e6e1c9}';document.head.appendChild(s)})();
window.newUni=function(){
 closeDD();$('home').style.display='none';var w=$('win');w.className='win on fwin';
 var ic=function(id,h,t){return '<div class="fi" id="ui_'+id+'" title="'+t+'">'+h+'</div>'};
 var tb=ic('help','<span class="q">?</span>','مساعدة')+ic('find','🔍','بحث')+'<div class="fgap"></div>'+ic('ok','<span style="color:#2f9e2f;font-size:24px;font-weight:700">✔</span>','تسجيل')+ic('eye','<span style="font-size:20px">👁</span>','تحقق');
 var h='<div class="usheet" id="ush"><div style="position:absolute;right:0;top:0;width:900px;height:50px;background:url(final-banner.jpg) right center/cover no-repeat"></div><div style="position:absolute;right:0;top:60px;width:445px;height:24px;background:#000046;color:#fff;font:700 11px Tahoma;line-height:24px;padding-right:12px">إيداع المستندات</div>';
 h+='<div class="ub" style="right:20px;top:140px">رمز الشركة</div><input class="ui" id="u_code" maxlength="12" style="right:120px;top:134px;width:239px">';
 h+='<div class="ub" style="right:20px;top:182px">اسم الشركة</div><textarea class="ui" id="u_name" readonly style="right:120px;top:177px;width:239px"></textarea>';
 h+='<div class="ub" style="right:20px;top:283px">تاريخ</div><input class="ui" id="u_date" readonly style="right:120px;top:278px;width:239px" value="'+today()+'">';
 h+='<div class="ub" style="right:20px;top:312px">التعليقات</div><textarea class="ui" id="u_cm" style="right:120px;top:308px;width:239px;height:40px"></textarea>';
 h+='<div class="ub" style="right:20px;top:372px">تسلسل</div><input class="ui" id="u_seq" readonly style="right:221px;top:367px;width:138px"><input class="ui" id="u_f" readonly style="right:202px;top:367px;width:18px;padding:2px;text-align:center"><input class="ui" id="u_sd" readonly style="right:120px;top:367px;width:80px">';
 h+='<div class="ub" style="right:419px;top:147px">نوع التصريحة</div><div class="ui" style="right:419px;top:165px;width:250px;height:20px;background:#ececf2"></div><div class="ub" style="right:432px;top:170px;font-weight:400">استيراد</div><div class="uck" id="u_im" style="right:420px;top:169px">✔</div><div class="ui" style="right:419px;top:192px;width:250px;height:20px"></div><div class="ub" style="right:432px;top:197px;font-weight:400">تصدير</div><div class="uck" style="right:420px;top:196px"></div>';
 h+='<div class="ubox" style="right:414px;top:246px;width:258px;height:63px"><div class="ub" style="right:5px;top:4px;color:#000">رقم الاجراء الموحد</div><input class="ui" id="u_no" readonly style="right:14px;top:30px;width:237px"></div>';
 h+='<div class="ubox" style="right:414px;top:316px;width:258px;height:63px"><div class="ub" style="right:5px;top:4px">مرجع التصريحة</div><input class="ui" id="u_ref" style="right:14px;top:30px;width:237px"></div>';
 h+='<div class="ubox" style="right:21px;top:415px;width:744px;height:286px"><div class="ucap">الملف (الملفات) المرفقة</div><div style="position:absolute;right:20px;top:32px;width:695px;height:244px;border:1px solid #888;background:#fff"><div style="height:42px;background:#e4dfc8;display:flex;align-items:center;gap:14px;padding:0 10px;font-size:20px;color:#555"><span>✖</span><span>💾</span><span>📄</span><span style="margin-right:auto;font-size:18px">🔍 ⏺ ⏸ ⟲</span></div><table style="width:100%;direction:ltr"><tr><th style="width:190px">Status</th><th>File name</th><th style="width:100px">Code</th></tr></table></div></div></div>';
 w.innerHTML='<div class="ftb">'+tb+'<span class="tt" id="utt">رقم الاجراء الموحد - جديد [n/a]</span></div><div class="fbody" id="fbody" style="background:#fff;overflow:auto">'+h+'</div><div class="msgw" id="msgw"></div><div class="ftask"><span>تفاصيل البيان - استعراض [n...]</span><span>مكتبة الوثائق</span><span class="on">رقم الاجراء الموحد - جديد [n/a]</span></div>';
 var done=false,code=$('u_code');
 code.addEventListener('input',function(){if(done)return;this.value=this.value.replace(/\D/g,'');if(!this.value)$('u_name').value=''});
 function fill(){if(done)return;var v=code.value.trim();if(v)$('u_name').value=fakeCo(v);else $('u_name').value=''}
 code.addEventListener('keydown',function(e){if(e.key==='Enter')fill()});code.addEventListener('blur',fill);
 function check(){var v=code.value.trim();if(!v){infoMsg('رمز الشركة غير مكتوب.');return false}return true}
 $('ui_help').onclick=function(){infoMsg('اكتب رمز الشركة (المستورد) ثم اضغط ✔ ليصدر رقم الإجراء الموحد، وبعدها اكتبه بحقل File Reference في البيان النهائي.')};
 $('ui_find').onclick=function(){infoMsg('البحث غير مفعّل في هذه المرحلة.')};
 $('ui_eye').onclick=function(){if(done)return;if(check())infoMsg('تم التحقق، لا توجد أخطاء.')};
 $('ui_ok').onclick=function(){if(done||!check())return;fill();var seq=nextSeq(),no='260'+seq;if(String(new Date().getFullYear()).slice(2)!=='26')no=String(new Date().getFullYear()).slice(2)+'0'+seq;
  UP.push({no:no,code:code.value.trim(),date:today()});save();
  $('u_no').value=no;$('u_seq').value=seq;$('u_f').value='F';$('u_sd').value=today();code.readOnly=true;$('u_cm').readOnly=true;$('u_ref').readOnly=true;
  $('utt').textContent='رقم الاجراء الموحد - جديد [F]';$('ui_ok').style.display='none';$('ui_eye').style.display='none';done=true;
  infoMsg('تم إصدار رقم الإجراء الموحد: <b dir="ltr">'+no+'</b>')};
 code.focus()};
})(window.SIM);
