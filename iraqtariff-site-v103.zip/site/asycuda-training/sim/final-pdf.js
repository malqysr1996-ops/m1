/* رفع البيان النهائي (✔) + رقم التسجيل C + تحميل PDF — بدون مكتبات خارجية */
(function(){
var $=function(i){return document.getElementById(i)};
function today(){return new Date().toLocaleDateString('en-GB')}
function box(text,btns){var o=ov('<div class="dh"><span>رسالة</span><i onclick="closeOv()">✕</i></div><div class="db"><span>'+text+'</span><span class="info">?</span></div><div style="display:flex;gap:10px;justify-content:center;padding:6px 0 10px" id="cb"></div>');
 btns.forEach(function(b){var x=document.createElement('button');x.className='ok';x.style.cssText='position:static;width:auto;padding:2px 18px;font:12px Tahoma';x.textContent=b[0];x.onclick=function(){closeOv();b[1]&&b[1]()};$('cb').appendChild(x)})}
/* ---- رفع البيان ---- */
function register(){
 var no=String(100000+Math.floor(Math.random()*900000)),d=today();
 FD.reg={no:no,date:d};FD.hdr.regno=d;FD.hdr.regdate='C '+no;
 var t=document.querySelector('#win .tt');if(t)t.textContent=t.textContent.replace(/\s*\[.*\]$/,'')+' [C '+no+']';
 if(FD.tab===0)buildFinalTab();
 infoMsg('تم رفع البيان<br>رقم البيان: <b dir="ltr">C '+no+'</b><br>التاريخ: <b dir="ltr">'+d+'</b>',function(){
  box('هل تريد تحميل الوثيقة PDF؟',[['نعم',downloadPdf],['لا']])})}
window.submitFinal=function(){
 snapFinal();
 if(FD.reg){box('البيان مرفوع مسبقاً برقم <b dir="ltr">C '+FD.reg.no+'</b>.<br>هل تريد تحميل الوثيقة PDF؟',[['نعم',downloadPdf],['لا']]);return}
 if(!verifyFinal(true))return;
 box('هل تريد تصفية البيان؟',[['موافق',register],['إلغاء']])};
/* ---- رسم صفحة على Canvas ---- */
var SC=2;
function drawPage(){
 var el=$('sad'),W=el.offsetWidth,H=el.offsetHeight,c=document.createElement('canvas');c.width=W*SC;c.height=H*SC;
 var x=c.getContext('2d');x.scale(SC,SC);x.fillStyle='#fff';x.fillRect(0,0,W,H);x.textBaseline='middle';
 function font(s){return (s.fontStyle==='italic'?'italic ':'')+s.fontWeight+' '+s.fontSize+' '+s.fontFamily}
 function text(str,e,s,bx,by,bw,bh,multi){
  if(str===''||str==null)return;x.font=font(s);x.fillStyle=s.color;var dir=s.direction,al=s.textAlign;
  if(al==='start')al=dir==='rtl'?'right':'left';else if(al==='end')al=dir==='rtl'?'left':'right';else if(al==='justify')al='left';
  x.direction=dir;var pl=parseFloat(s.paddingLeft)||0,pr=parseFloat(s.paddingRight)||0,lh=parseFloat(s.lineHeight)||parseFloat(s.fontSize)*1.25;
  var ax=al==='center'?bx+bw/2:al==='right'?bx+bw-pr:bx+pl;x.textAlign=al;
  var lines=[];String(str).split('\n').forEach(function(ln){if(!multi){lines.push(ln);return}
   var cur='';ln.split(' ').forEach(function(w){var t=cur?cur+' '+w:w;if(x.measureText(t).width>bw-pl-pr&&cur){lines.push(cur);cur=w}else cur=t});lines.push(cur)});
  lines.forEach(function(ln,i){var cy=multi?by+lh*i+lh/2:by+bh/2;x.fillText(ln,ax,cy)})}
 Array.prototype.forEach.call(el.children,function(e){
  var s=getComputedStyle(e),bx=e.offsetLeft,by=e.offsetTop,bw=e.offsetWidth,bh=e.offsetHeight,tg=e.tagName;
  if(tg==='IMG'){try{x.drawImage(e,bx,by,bw,bh)}catch(_){}return}
  if(s.backgroundColor&&s.backgroundColor!=='rgba(0, 0, 0, 0)'){x.fillStyle=s.backgroundColor;x.fillRect(bx,by,bw,bh)}
  [['Top',bx,by,bw,0],['Bottom',bx,by+bh,bw,0],['Left',bx,by,0,bh],['Right',bx+bw,by,0,bh]].forEach(function(sd){
   var w=parseFloat(s['border'+sd[0]+'Width']),st=s['border'+sd[0]+'Style'];if(!(w>0)||st==='none')return;
   x.strokeStyle=s['border'+sd[0]+'Color'];x.lineWidth=w;x.setLineDash(st==='dashed'?[6,4]:[]);x.beginPath();
   if(sd[0]==='Top'||sd[0]==='Bottom'){var yy=sd[0]==='Top'?by+w/2:by+bh-w/2;x.moveTo(bx,yy);x.lineTo(bx+bw,yy)}else{var xx=sd[0]==='Left'?bx+w/2:bx+bw-w/2;x.moveTo(xx,by);x.lineTo(xx,by+bh)}x.stroke();x.setLineDash([])});
  if(tg==='INPUT')text(e.value,e,s,bx,by,bw,bh,false);
  else if(tg==='TEXTAREA')text(e.value,e,s,bx,by,bw,bh,true);
  else if(e.classList.contains('ck')){if(e.getAttribute('data-v')==='1'){x.textAlign='center';x.font=font(s);x.fillStyle='#000';x.fillText('✔',bx+bw/2,by+bh/2)}}
  else if(e.children.length&&e.id==='foff'){var b=e.querySelector('b');text(b?b.textContent:'',e,getComputedStyle(b||e),bx,by,bw,bh,false)}
  else if(!e.children.length||tg==='SPAN'||e.classList.contains('fb')){var t=e.innerText;if(t)text(t.replace(/\s+$/,''),e,s,bx,by,bw,bh,t.indexOf('\n')>=0)}
 });
 return c}

/* ---- الصفحة الأولى بنفس شكل ملف ASYCUDA ---- */
function loadTpl(cb){var im=new Image();im.onload=function(){cb(im)};im.onerror=function(){cb(null)};im.src='final-pdf-template.jpg'}
function drawSample(im){
 var K=im.width/595,c=document.createElement('canvas');c.width=im.width;c.height=im.height;var x=c.getContext('2d');x.drawImage(im,0,0);
 var H=FD.hdr,I=FD.items[0]||{},F=FD.fees,o=fOff();
 function T(str,px,py,al,sz){if(str===undefined||str===null||String(str).trim()==='')return;str=String(str);
  x.font=(sz||8)*K+'px Arial,Tahoma,sans-serif';x.fillStyle='#000';x.textBaseline='middle';x.textAlign=al==='r'?'right':al==='c'?'center':'left';
  x.direction=/[؀-ۿ]/.test(str)?'rtl':'ltr';x.fillText(str,px*K,py*K)}
 function L(str,px,py,al,lh){String(str||'').split('\n').forEach(function(t,i){T(t,px,py+i*(lh||9.5),al)})}
 T(H.fileref,30,21,'l');T(o.c,179,24,'l');T(o.n,192,38,'r');
 T(H.b1b,242,36,'l');T(H.b1c,260,36,'l');
 if(FD.reg){T(FD.reg.date,74,60,'l');T(FD.reg.no,148,60,'l');T('C',183,60,'l')}
 L(H.exp_addr,290,58,'l',9);
 T(String(H.manifest||'').replace('/',' '),110,72,'l');T('1',250,72,'l');T(String(1+FD.pg),270,72,'l');
 T(H.ref7a,114,96,'l');T(H.ref7||'2026',158,97,'l');T(H.pkgs6,213,97,'l');T(String(usedN()),270,97,'l');
 T(H.imp_no,358,112,'l');L(H.imp_addr,516,123,'r',9.5);
 T(H.c12||'0',172,171,'l');
 T('25000073',359,188,'l');T('وكيل الاخراج / (اسم تدريبي)',516,198,'r');T('بغداد - تدريبي',516,208,'r');
 T(H.c17fa,82,196,'l');T(H.c15a,141,196,'l');T(H.c15n,274,196,'r');T(H.c16n,274,221,'r');T(H.c17n,150,221,'r');
 T([H.c20c||H.c20a,H.c20n].filter(Boolean).join(' '),274,246,'r');if(H.container)T('yes',289,246,'l');
 var rate=H.c23||((window.CV_RATES&&CV_RATES[(H.c22b||'').toUpperCase()])?Number(CV_RATES[(H.c22b||'').toUpperCase()]).toLocaleString('en-US',{minimumFractionDigits:3}):'');
 T(rate,116,272,'l');T(H.c22a?String(H.c22a).replace(/\.00$/,''):'',214,273,'l');T(H.c22b,257,272,'l');
 T(H.c28a,128,287,'l');T(H.c28b,182,299,'r');T(H.c28c,195,299,'l');T(H.c28d,274,311,'r');T([H.c28e,H.c28f].filter(Boolean).join(' '),135,323,'l');
 T(H.c28g,516,321,'r');T(H.c28h,489,321,'r');T(H.c30c,375,321,'l');T(H.c25,513,297,'l');
 T(I.i31marks||H.i31marks,452,348,'l');T(I.i31pk,417,374,'l');T(I.i31cnt,438,374,'l');
 T(I.i1,43,346,'l');T(I.i4,138,347,'l');T(String(I.i33||'').slice(0,8),173,347,'l');T('1',251,347,'l');
 T(I.i34a,201,373,'l');T(I.i35,105,372,'l');T(I.i37a,191,397,'l');T(I.i37b||'000',162,397,'l');T(I.i38,105,396,'l');
 T([I.i40a,I.i40b].filter(Boolean).join(' '),137,423,'l');
 T(I.desc1,474,415,'r');T(I.desc2||I.desc1,475,433,'r');
 T(I.i41c,141,448,'l');T(I.i41d,191,448,'l');T(I.i41b?String(I.i41b).replace(/\.00$/,''):'',101,447,'l');
 T('0+0+0+0-0',477,460,'l');
 var codes=(window.reqDocs?reqDocs(!!(H.manifest&&H.manifest!=='2026/')).map(function(r){return r[0]}):[]).filter(function(cd){return FD.att&&FD.att[cd]&&FD.att[cd].ref});
 T(codes.join(' '),474,472,'r');T('1.000',79,472,'l');T(I.i46,81,499,'l');
 for(var r=0;r<8;r++){var a=I['A'+r];if(!a)continue;var y=526+12*r;T('1',285,y,'c');T(I['D'+r],329.5,y,'c');T(I['C'+r],395,y,'c');T(I['B'+r],461.5,y,'c');T(a,508,y,'c')}
 if(F){T('1',285,626,'c');T(I.tot,341,626,'c');T('الدفع نقداً',190,555,'r');T('0',190,597,'r');T('81,000',190,611,'r');T(((F.sum||0)+81000).toLocaleString('en-US'),190,625,'r')}
 /* نصوص جانبية + رموز QR/باركود تدريبية */
 x.save();x.translate(585*K,141*K);x.rotate(Math.PI/2);T('ASYCUDAWorld',0,0,'c',7);x.restore();
 x.save();x.translate(585*K,754*K);x.rotate(-Math.PI/2);T('ASYCUDAWorld ©',0,0,'c',7);x.restore();
 var seed=Number(FD.reg?FD.reg.no:7)||7;function rnd(){seed=(seed*16807)%2147483647;return seed/2147483647}
 x.fillStyle='#000';var q=61/21;for(var i=0;i<21;i++)for(var j=0;j<21;j++){var fin=(i<7&&j<7)||(i<7&&j>13)||(i>13&&j<7);var on=fin?((i%6===0||j%6===0||(i%6>=2&&i%6<=4&&j%6>=2&&j%6<=4))&&!(i>=7&&i<=13)):rnd()>.5;if(on)x.fillRect((526+j*q)*K,(44+i*q)*K,q*K,q*K)}
 for(var bx=58;bx<168;bx+=1.2){if(rnd()>.45)x.fillRect(bx*K,657*K,(0.6+rnd()*0.8)*K,59*K)}
 return c}

/* ---- كاتب PDF بسيط ---- */
function u8(str){var a=new Uint8Array(str.length);for(var i=0;i<str.length;i++)a[i]=str.charCodeAt(i)&255;return a}
function makePdf(jpgs){ /* jpgs: [{data:Uint8Array,w,h}] */
 var parts=[],off=0,xref=[];function put(a){if(typeof a==='string')a=u8(a);parts.push(a);off+=a.length}
 function obj(n,body){xref[n]=off;put(n+' 0 obj\n');put(body);put('\nendobj\n')}
 put('%PDF-1.4\n');var n=jpgs.length,PW=595.28,PH=841.89,kids=[];
 obj(1,'<< /Type /Catalog /Pages 2 0 R >>');
 for(var i=0;i<n;i++)kids.push((3+i*3)+' 0 R');
 obj(2,'<< /Type /Pages /Kids ['+kids.join(' ')+'] /Count '+n+' >>');
 jpgs.forEach(function(j,i){var pn=3+i*3,cn=pn+1,im=pn+2,sc=Math.min(PW/j.w,PH/j.h),w=j.w*sc,h=j.h*sc,ox=(PW-w)/2,oy=PH-h-10;
  obj(pn,'<< /Type /Page /Parent 2 0 R /MediaBox [0 0 '+PW+' '+PH+'] /Contents '+cn+' 0 R /Resources << /XObject << /Im0 '+im+' 0 R >> >> >>');
  var cs='q '+w.toFixed(2)+' 0 0 '+h.toFixed(2)+' '+ox.toFixed(2)+' '+oy.toFixed(2)+' cm /Im0 Do Q';
  obj(cn,'<< /Length '+cs.length+' >>\nstream\n'+cs+'\nendstream');
  xref[im]=off;put(im+' 0 obj\n<< /Type /XObject /Subtype /Image /Width '+j.w+' /Height '+j.h+' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '+j.data.length+' >>\nstream\n');put(j.data);put('\nendstream\nendobj\n')});
 var total=3+n*3,xs=off;put('xref\n0 '+total+'\n0000000000 65535 f \n');
 for(var k=1;k<total;k++)put(('0000000000'+xref[k]).slice(-10)+' 00000 n \n');
 put('trailer\n<< /Size '+total+' /Root 1 0 R >>\nstartxref\n'+xs+'\n%%EOF');
 return new Blob(parts,{type:'application/pdf'})}
function dataU8(url){var b=atob(url.split(',')[1]),a=new Uint8Array(b.length);for(var i=0;i<b.length;i++)a[i]=b.charCodeAt(i);return a}
function downloadPdf(){
 loadTpl(function(im){
  var sv={page:FD.page,tab:FD.tab},pgs=[];
  try{snapFinal();FD.tab=0;
   if(im){var c0=drawSample(im);pgs.push({data:dataU8(c0.toDataURL('image/jpeg',.92)),w:c0.width,h:c0.height})}
   for(var p=im?1:0;p<=FD.pg;p++){FD.page=p;buildFinalTab();var c=drawPage();pgs.push({data:dataU8(c.toDataURL('image/jpeg',.92)),w:c.width,h:c.height})}
  }finally{FD.page=sv.page;FD.tab=sv.tab;buildFinalTab()}
  var blob=makePdf(pgs),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='declaration-'+(FD.reg?'C'+FD.reg.no:'draft')+'.pdf';document.body.appendChild(a);a.click();setTimeout(function(){URL.revokeObjectURL(a.href);a.remove()},1500)})}
window.downloadFinalPdf=downloadPdf;
/* ---- قفل بعد الرفع + ربط الأزرار ---- */
var ob=window.buildFinalTab;window.buildFinalTab=function(){ob();
 if(FD&&FD.reg&&FD.tab===0){document.querySelectorAll('#sad input,#sad textarea').forEach(function(i){i.readOnly=true});document.querySelectorAll('#sad .ck,#sad #foff').forEach(function(i){i.style.pointerEvents='none'})}};
document.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('#fi_ok,#fi_print,#fi_print2');if(!b||!$('sad')&&!$('fbody'))return;
 if(b.classList.contains('off'))return;e.stopImmediatePropagation();e.preventDefault();
 if(b.id==='fi_ok')submitFinal();else{if(FD.reg)downloadPdf();else infoMsg('الطباعة تعمل بعد رفع البيان (✔).')}},true);
})();
