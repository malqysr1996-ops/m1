/* منطق حقول البيان النهائي (محاكي تدريبي) — القوائم مأخوذة من فيديوهات المستخدم */
(function(S){
function L(s){return s.split('|').map(function(x){var i=x.indexOf(':');return {c:x.slice(0,i),n:x.slice(i+1)}})}
/* أنواع الطرود (التوصية 21) — كما ظهرت في الفيديو */
S.pkgs=L("AE:بخاخ|AM:كبسولة غير محمية|AN:حيوانات حية|AP:كبسولة محمية|AT:رشاش|BA:برميل , برميل (للسوائل) , برميل صغير|BB:لفة (سلك فولاذ)|BC:صندوق زجاجات|BD:لوحة اعلانات|BE:رزمة|BF:بالون غير محمي|BG:حقيبة , كيس|BH:حزمة|BI:صندوق حنطة|BJ:باكيت , حوض|BK:احجام كبيرة(سائبة )|BL:بالة , كيس|BN:رزمة غير مضغوطة|BO:زجاجة اسطوانية غير محمية|BP:بالون محمي|BQ:زجاجة اسطوانية محمية|BR:قضيب|BS:زجاجة منتفخة غير محمية|BT:برغي|BU:طرف غليظ مستدير|BV:زجاجة منتفخة محمية|BX:صندوق , علبة , قفص|BY:الواح , بحزم أو مجموعات أو رزم|BZ:قضبان, بحزم أو مجموعات أو تركيبات|CA:مركبة|CB:صندوق بيرة|CC:ممخضة اللبن|CE:سلة صياد السمك|CF:صندوق حديدي|CG:قفص , صندوق , تنكة (مستطيل)|CH:صندوق كبير بادراج|CI:علبة صغيرة, علبة (مستطيل)|CJ:تابوت|CK:برميل خشبي|CL:لفة من اسلاك كهربائية او حبال|CN:حاوية|CO:قنينة غير مغطاة|CP:قنينة مغطاة بقش|CR:صندوق شحن|CS:علب مغلفة|CT:كرتونة|CU:كوب|CV:غطاء|CX:علبة (أسطوانية)|CY:أسطوانة , قضيب , جذع (طويل , قاسي)|CZ:شادر|DF:مختلف|DJ:زجاجة ضخمة غير مكسوة|DP:زجاجة ضخمة مكسوة بالقش|DZ:دزينة|EN:مغلف|FC:صندوق شحن للفواكة|FD:صندوق شحن مؤطر|FI:برميل خشبي للزبدة|FL:قنينة|FO:خزانة احذية|FP:علبة افلام|FR:إطار , هيكل , صندوق|FX:حقيبة، حاوية مرنة|GB:أسطوانة غاز (أسطوانة ضغط)|GI:عارضة|GL:جالون|GR:كروز|GZ:لوح,عارضة,لوح خشب ثقيل,عريض,حزمة|HG:برميل كبير سعة 238.5 لتر|HR:سلة كبيرة ذات غطاء|IN:قالب للصب|IZ:سبائك ضمن رزم أو مجموعات أو تركيبات|JC:صفيحة لحمل الوقود مستطيلة|JG:ابريق|JR:جرة|JT:حقيبة من ليف القنب|JY:صفيحة لحمل الوقود اسطوانية|KF:قفة|KG:برميل خشبي صغير (لغاية 45 لتر)|KT:طقم|LG:جذع شجرة|LQ:سائلة|LZ:جذوع ضمن رزم أو مجموعات أو تركيبات|MA:الة ,مجموعة , طقم , جهاز , وحدة|MB:حقيبة من جدران متعددة الطبقات|MC:صندوق حليب|MG:سيارة صيني|MS:كيس من جدران متعدد الطبقات|MT:حصيرة|MV:مركبة|MX:علبة ثقاب|NE:غير موضب|NS:مجموعة متداخلة|NT:شبكة|PA:زوج|PB:باليت , صندوق|PC:ربطة|PE:سبيكة (بيليت)|PG:صفيحة|PH:جرة|PI:قطعة|PK:رزمة , باكيت , طرد|PL:عبر الانبوب|PN:لوح خشب|PO:كيس أو جراب|PP:جزء طرد|PR:زوج|PT:قدر أو بوتقة|PU:مجموعة صواني|PV:أنابيب وقساطل (طويلة فارغة)|PX:باليت|PY:صفائح ضمن حزم, مجموعات, تركيبات|PZ:ألواح خشب ضمن حزم, مجموعات, تركيبات|RD:عود|RG:حلقة|RL:بكرة|RO:لفة|RT:ردنت (شبكة حمراء)|SA:جيب|SC:صندوق مسطح (ضحل)|SD:جذع , ذراع|SE:صندوق بحري|SF:أجهزة سلامة عامة|SH:كيس|SK:صندوق هيكلي|SL:صفيحة عازلة|SM:لوح معدني|ST:مسطح , ورقة|SU:حقيبة ثياب|SW:لفائف منكمشة|SZ:الواح ضمن حزم, مجموعات, تركيبات|TB:حوض استحمام|TC:صندوق للشاي|TD:انبوب قابل للطي|TK:صهريج مستطيل|TN:علبة|TO:برميل خشبي للسوائل (خمرة)|TR:صندوق عدة وادوات|TS:تركيبة|TU:أنبوب|TY:أسطوانة , تنكة (أسطوانية)|VA:حوض كبير للتكرير او للتخمير او للدباغة|VG:دكمة , غاز (على 1.31 ملم بار , د15)|VH:عربة شاحنة الية|VI:قارورة|VL:دكمة , سائل|VO:دكمة , صلب , كلل|VP:مفرغة من الهواء|VQ:دكمة , غاز سائل|VR:دكمة , صلب , حبيبات|VT:ملبوسات|VY:دكمة , صلب , بودرة|WB:زجاجة مغطاة بأنسجة");
/* الأوضاع الجمركية (الحقل 37) */
S.regimes=L("4000:وضع للاستهلاك قطاع خاص|4050:استيراد دائم تبعا لإدخال مؤقت|4051:استيراد دائم تبعا لإدخال مؤقت لأنجاز المشاريع|4052:استيراد دائم تبعا لإدخال مؤقت بقصد الاصلاح|4053:استيراد دائم تبعا لإدخال مؤقت للملاعب والمسارح والمعارض او ما يماثلها|4054:استيراد دائم تبعا لإدخال مؤقت للتصنيع او اعادة التصنيع|4055:استيراد دائم تبعا لادخال مؤقت للعينات التجارية|4056:استيراد دائم تبعا لادخال مؤقت للاوعية والغلافات|4057:استيراد دائم تبع لإدخال مؤقت المواشي المدخلة للرعي|4058:استيراد دائم تبعا لأدخال مؤقت خاص|4070:استيراد دائم تبعا لادخال الى المخازن الكمركية|4071:استيراد دائم تبعا لادخال الى المناطق الحرة|4074:استيراد دائم تبعا لادخال الى مخازن الحرة من مناطق غير مؤتمنة|4092:استيراد دائم تبعا لبيان مؤقت|4096:الإجراء العام تبعا لدفع مسبق|4100:استيراد للوضع للاستهلاك عبر إقليم كردستان|4200:وضع للاستهلاك مبسط للمسافرين|4300:استيراد وضع للاستهلاك الشخصي حسب القيمة|4400:استيراد وضع للاستهلاك لبضائع للاستهلاك الشخصي|4500:الوضع للاستهلاك للقطاع العام");
/* نوع البيان (الحقل 1) */
S.fTypes=[{c:'EX1',n:'تصدير دائم',im:'EX',no:'1'},{c:'EX2',n:'تصدير مؤقت',im:'EX',no:'2'},{c:'EX3',n:'إعادة تصدير',im:'EX',no:'3'},{c:'EX9',n:'أنظمة جمركية أخرى على التصدير',im:'EX',no:'9'},{c:'IM4',n:'استيراد دائم',im:'IM',no:'4'},{c:'IM5',n:'إدخال مؤقت',im:'IM',no:'5'},{c:'IM6',n:'إعادة استيراد',im:'IM',no:'6'},{c:'IM7',n:'إدخال إلى مخزن كمركي',im:'IM',no:'7'},{c:'IM9',n:'أنظمة جمركية أخرى على الاستيراد',im:'IM',no:'9'},{c:'EXS',n:'تصدير مبسط',im:'EX',no:'S'},{c:'IMS',n:'استيراد مبسط',im:'IM',no:'S'},{c:'DTP',n:'بيان مؤقت (تعهد)',im:'DT',no:'1'},{c:'IMK',n:'استيراد دائم عبر منفذ إبراهيم الخليل',im:'IM',no:'K'},{c:'TR1',n:'ترانزيت',im:'TR',no:'1'}];
})(window.SIM);

(function(S){
var $q=function(sel){return document.querySelector(sel)};
function Q(n,k){return $q('#sad [data-n="'+n+'"]'+(k===undefined||k===null?':not([data-k])':'[data-k="'+k+'"]'))}
function digits(e,max){e.addEventListener('input',function(){var v=this.value.replace(/\D/g,'');this.value=max?v.slice(0,max):v})}
function open(anchor,items,render,pick){var host=$('fbody');var d=dropdown(anchor,items,render,pick);d.style.top=(parseFloat(d.style.top)+host.scrollTop)+'px';d.style.maxHeight='200px';d.style.minWidth='300px';return d}
function arrow(inp,onopen){ /* سهم ▽ صغير بجانب الحقل */
 var a=document.createElement('span');a.className='fpk';a.textContent='▽';a.setAttribute('data-dd','1');
 a.style.cssText='position:absolute;font-size:9px;color:#3b3b9a;cursor:pointer;line-height:12px;z-index:3;left:'+(parseFloat(inp.style.left)-10)+'px;top:'+(parseFloat(inp.style.top)+2)+'px';
 a.onmousedown=function(e){e.preventDefault();e.stopPropagation();onopen()};inp.parentNode.appendChild(a)}
/* حقل رمز مع قائمة: يملأ اسمه في حقل آخر */
function codeField(inp,list,o){o=o||{};if(!inp)return;
 var nm=o.nameInp;function setBy(it){inp.value=it.c;if(nm)nm.value=it.n;if(o.after)o.after(it)}
 function resolve(){var v=inp.value.trim().toUpperCase();if(!v){if(nm)nm.value='';return}var bs=o.suffix?v.split('/')[0]:v;var it=list.filter(function(x){return String(x.c).toUpperCase()===bs})[0];if(it){setBy(it);if(o.suffix&&v.indexOf('/')>0)inp.value=v}else{inp.value='';if(nm)nm.value=''}}
 function pop(){open(inp,list,function(x){return '<span>'+x.n+'</span><b>'+x.c+'</b>'},setBy)}
 if(!inp.readOnly){arrow(inp,pop);inp.addEventListener('dblclick',pop);inp.addEventListener('keydown',function(e){if(e.key==='F4'||(e.key==='ArrowDown'&&e.altKey)){e.preventDefault();pop()}if(e.key==='Enter'){resolve();closeDD()}});inp.addEventListener('blur',function(){setTimeout(resolve,130)})}
 return {resolve:resolve,set:setBy}}
function unitOf(ar){ar=String(ar||'');var m=[['كيلو','KGM'],['طن','TNE'],['لتر','LTR'],['متر مربع','MTK'],['متر مكعب','MTQ'],['متر','MTR'],['زوج','PR'],['طقم','SET'],['عدد','NMB'],['قطعة','NMB']];for(var i=0;i<m.length;i++)if(ar.indexOf(m[i][0])===0)return m[i][1];return 'KGM'}
/* مجموع الفاتورة = مجموع أسعار البنود (الحقل 42) */
function invTotal(){var t=0;(FD.items||[]).forEach(function(it,k){var live=Q('i41b',k);var v=live?live.value:it.i41b;var n=num(v);if(!isNaN(n))t+=n});return t}
function syncTotal(){}
/* تعبئة بند من التعرفة */
function setFCode(k,r){var c=Q('i33',k);if(!c)return;c.value=String(r[0]).slice(0,8);var z=Q('i4',k);if(z)z.value='000';var d=Q('desc1',k);if(d)d.value=r[1]||'';var d2=Q('desc2',k);if(d2)d2.value='';var t1=Q('i1',k);if(t1)t1.value='تدريبي';
 var u=unitOf(r[2]);var ud=Q('i41d',k);if(ud)ud.value=u;syncQty(k)}
function syncQty(k){var ud=Q('i41d',k),uc=Q('i41c',k),nw=Q('i38',k);if(ud&&uc&&ud.value==='KGM'&&nw)uc.value=nw.value}
function fSelectCode(cb){
 if(!TARIFF){loadTariff()}
 var o=ov('<div class="sh"><span>بحث المنتج</span><i onclick="closeOv()">✕</i></div><div class="f"><label>الرمز <input id="sc_c" autocomplete="off"></label><label>Description <input id="sc_d" autocomplete="off" style="direction:rtl;text-align:right"></label></div><div class="tw"><table><thead><tr><th>الرمز</th><th>Description</th><th>Unit</th><th>Valid From</th><th>Valid To</th></tr></thead><tbody id="sc_b"></tbody></table></div><button class="okb" id="sc_ok">✔</button>','sel-dlg');
 var sel=null;function draw(){var c=$('sc_c').value.trim(),d=$('sc_d').value.trim(),rows=[],T=TARIFF||[];for(var i=0;i<T.length&&rows.length<150;i++){var r=T[i];if(c&&String(r[0]).indexOf(c)!==0)continue;if(d&&String(r[1]).indexOf(d)<0)continue;rows.push(r)}
  var h='';rows.forEach(function(r,i){h+='<tr data-i="'+i+'"><td>'+r[0]+'000</td><td>'+String(r[1]||'').replace(/</g,'&lt;')+'</td><td>'+(r[2]||'')+'</td><td>01/08/2024</td><td></td></tr>'});$('sc_b').innerHTML=h||'<tr><td colspan="5" style="text-align:center;color:#889">'+(TARIFF?'لا نتائج':'جاري تحميل جدول التعرفة...')+'</td></tr>';sel=null;
  $('sc_b').querySelectorAll('tr[data-i]').forEach(function(tr){tr.onclick=function(){$('sc_b').querySelectorAll('tr').forEach(function(x){x.classList.remove('sel')});tr.classList.add('sel');sel=rows[+tr.getAttribute('data-i')]};tr.ondblclick=function(){sel=rows[+tr.getAttribute('data-i')];done()}})}
 function done(){if(sel){closeOv();cb(sel)}}
 $('sc_c').oninput=draw;$('sc_d').oninput=draw;$('sc_ok').onclick=done;draw();var t=setInterval(function(){if(TARIFF){clearInterval(t);if($('sc_b'))draw()}},400);$('sc_c').focus()}
function fakeCo(v){var n=0;for(var i=0;i<v.length;i++)n=(n*31+v.charCodeAt(i))%9973;return S.fakeCompanies[n%S.fakeCompanies.length]+'\nالعراق — بغداد — عنوان تدريبي'}

window.attachFinal=function(){
 if(!$('sad'))return;
 var main=FD.page===0;
 /* ---- حقول الصفحة الرئيسية ---- */
 if(main){
  /* 1: نوع البيان */
  var b1c=Q('b1c'),b1b=Q('b1b');
  if(b1c){b1c.readOnly=true;var pick=function(){open(b1c,S.fTypes,function(x){return '<span>'+x.n+'</span><b>'+x.c+'</b>'},function(x){b1c.value=x.im;b1b.value=x.no;FD.hdr.ftype=x.c})};arrow(b1c,pick);b1c.addEventListener('click',pick);b1c.style.cursor='pointer'}
  /* 7: 2026 + مسافة + رقم المسبق */
  var r7=Q('ref7a');if(r7)r7.addEventListener('keydown',function(e){if(e.key==='Enter'){var n=Q('i33',0);if(n)n.focus()}});
  /* المانيفست 2026/ثلاث خانات */
  var mf=Q('manifest');if(mf){if(!mf.value)mf.value='2026/';mf.maxLength=9;mf.setAttribute('dir','ltr');mf.style.textAlign='left';mf.addEventListener('input',function(){var v=this.value.replace(/[^0-9\/]/g,'');var m=(v.indexOf('2026/')===0?v.slice(5):v).replace(/\D/g,'').slice(0,3);this.value='2026/'+m});mf.addEventListener('blur',function(){if(!/^2026\/\d{3}$/.test(this.value))this.value=this.value.length>5?'':this.value})}
  /* 8: المستورد — رمز من 8 أرقام يظهر اسم شركة تدريبية */
  var imp=Q('imp_no'),ia=Q('imp_addr');if(imp&&ia){digits(imp,8);var fill=function(){var v=imp.value.trim();if(!v){ia.value='';return}if(v.length!==8){imp.value='';ia.value='';return}ia.value=fakeCo(v)};imp.addEventListener('keydown',function(e){if(e.key==='Enter')fill()});imp.addEventListener('blur',fill)}
  /* 15 / 17 */
  codeField(Q('c15a'),S.countries,{nameInp:Q('c15n')});
  var f17=Q('c17fa');if(f17){f17.value='IQ';f17.readOnly=true}var n17=Q('c17n');if(n17){n17.value='العراق';n17.readOnly=true}
  /* 22: العملة والمبلغ */
  codeField(Q('c22b'),S.currencies);var a22=Q('c22a');if(a22){if(!a22.value)a22.value='0.00';a22.addEventListener('blur',function(){var n=num(a22.value);a22.value=isNaN(n)?'0.00':fmt(n)})}
  /* 28: شروط الدفع + المصرف */
  codeField(Q('c28c'),S.payTerms,{nameInp:Q('c28b')});
  var bk=Q('c28a'),bn=Q('c28d');if(bk&&bn){var bl=S.banks.map(function(x){return {c:x.c,n:x.n}});if(!bl.some(function(x){return x.c==='6'}))bl.unshift({c:'6',n:'المصرف الصناعي'});codeField(bk,bl,{nameInp:bn})}
  /* 29 (مكتب)، 30 (مكان وجود البضاعة) */
  codeField(Q('c28g'),S.offices,{nameInp:Q('c28h')});
  codeField(Q('c30c'),S.offices,{nameInp:Q('c30a'),suffix:true});
  /* 31: عدد الطرود + نوع الطرد */
  var pk=Q('i31pk',0);
 }
 /* ---- حقول البنود (في كل الصفحات) ---- */
 document.querySelectorAll('#sad [data-n="i33"]').forEach(function(c){var k=+c.getAttribute('data-k');
  digits(c,11);
  c.addEventListener('contextmenu',function(e){showCtx(e,[['بحث',function(){fSelectCode(function(r){setFCode(k,r)})}],['نسخ'],['لصق']])});
  var look=function(){var v=c.value.trim();if(!v)return;if(v.length<8){c.value='';return}c.value=v.slice(0,8);var z0=Q('i4',k);if(z0)z0.value=v.length>=11?v.slice(8,11):'000';if(!TARIFF){return}var key=v.slice(0,8);var r=TARIFF.filter(function(x){return String(x[0])===key})[0];if(r)setFCode(k,r);else{c.value='';infoMsg('البند الجمركي غير موجود.')}};
  c.addEventListener('keydown',function(e){if(e.key==='Enter')look()});c.addEventListener('blur',function(){setTimeout(look,150)});
  /* 34: بلد المنشأ */
  codeField(Q('i34a',k),S.countries);
  /* 37: الوضع الجمركي */
  var r37=Q('i37a',k),s37=Q('i37b',k);if(r37){r37.maxLength=4;digits(r37,4);codeField(r37,S.regimes,{after:function(){if(s37&&!s37.value)s37.value='000'}})}
  /* 31: نوع الطرد */
  var pkE=Q('i31pk',k),vh=Q('veh1',k);if(pkE&&vh&&!pkE.getAttribute('data-sw')){['left','top','width'].forEach(function(p){var t=pkE.style[p];pkE.style[p]=vh.style[p];vh.style[p]=t});pkE.setAttribute('data-sw','1')}if(pkE){var pp=function(){open(pkE,S.pkgs,function(x){return '<span>'+x.n+'</span><b>'+x.c+'</b>'},function(x){pkE.value=x.c+'  '+x.n})};arrow(pkE,pp);pkE.addEventListener('dblclick',pp);pkE.addEventListener('keydown',function(e){if(e.key==='F4'){e.preventDefault();pp()}})}
  /* 38 الوزن الصافي ← 41 (كغم) */
  var nw=Q('i38',k);if(nw)nw.addEventListener('input',function(){syncQty(k)});
  /* 42 السعر ← مجموع الفاتورة */
  var pr=Q('i41b',k);if(pr)pr.addEventListener('input',function(){syncTotal()});
  var pr1=Q('i41b',k);if(pr1)pr1.addEventListener('blur',function(){var n=num(pr1.value);if(!isNaN(n))pr1.value=fmt(n);syncTotal()});
 });
 [['i35'],['i38']].forEach(function(a){document.querySelectorAll('#sad [data-n="'+a[0]+'"]').forEach(function(e){e.addEventListener('blur',function(){var n=num(e.value);if(!isNaN(n))e.value=n.toLocaleString('en-US',{minimumFractionDigits:3,maximumFractionDigits:3})})})});
 if(!TARIFF)loadTariff();
 if(window.fillPageTot)fillPageTot();
};

/* ---------- زر العين: التحقق ---------- */
(function(){var st=document.createElement('style');st.textContent='.sad .fx.fbad{background:#ffd9d9!important;outline:1px solid #d33}';document.head.appendChild(st)})();
var REQ=[['001','فاتورة'],['003','شهادة منشأ'],['005','هوية استيراد'],['004','بوليصة شحن'],['057','وكالة'],['056','إيصال التتبع الإلكتروني'],['994','المطابقة والسيطرة النوعية'],['008','أمر التسليم']];
window.verifyFinal=function(quiet){snapFinal();if(window.hideMsgs)hideMsgs();var H=FD.hdr,I=FD.items,err=[],bad=[],docErr=0;
 function e(msg,n,k){err.push(msg);if(n)bad.push([n,k])}
 function emp(v){return v===undefined||v===null||String(v).trim()===''}
 /* الصفحة الرئيسية */
 if(emp(H.fileref))e('File Reference: رقم الإجراء الموحد غير مكتوب (أنشئه أولاً من قائمة رقم الإجراء الموحد)','fileref');else if(window.UPROCS&&!UPROCS.some(function(u){return u.no===String(H.fileref).trim()}))e('File Reference: رقم الإجراء الموحد غير صحيح أو لم يتم إنشاؤه','fileref');
 if(emp(H.b1c)||emp(H.b1b))e('الحقل 1: نوع البيان غير مكتوب','b1c');
 if(emp(H.ref7a))e('الحقل 7: رقم المعاملة بسجل المخلص غير مكتوب','ref7a');
 var mfOn=!emp(H.manifest)&&H.manifest!=='2026/';if(mfOn&&!/^2026\/\d{3}$/.test(H.manifest))e('رقم المانيفست غير مكتمل (2026/ثم 3 أرقام)','manifest');
 if(emp(H.exp_addr))e('الحقل 2: المصدر/المرسل غير مكتوب','exp_addr');
 if(emp(H.imp_no)||emp(H.imp_addr))e('الحقل 8: المستورد/المرسل إليه غير مكتوب','imp_no');
 if(emp(H.c15a))e('الحقل 15: رمز بلد المصدر غير مكتوب','c15a');
 if(emp(H.c22b))e('الحقل 22: رمز العملة غير مكتوب','c22b');
 if(emp(H.c28c))e('الحقل 28: شروط الدفع غير مكتوبة','c28c');
 if(emp(H.c28a))e('الحقل 28: رمز المصرف غير مكتوب','c28a');
 var f28=((H.c28e||'')+' '+(H.c28f||'')).replace(/\s+/g,' ').trim();if(!/^2026 ?\d+$/.test(f28.replace(/^2026 /,'2026 ')))e('الحقل 28: اكتب 2026 ثم مسافة ثم رقم البيان المسبق','c28f');
 var oc=String(FD.off||'');if(emp(H.c28g))e('الحقل 29: المركز الجمركي غير مكتوب','c28g');else if(String(H.c28g).trim()!==oc)e('الحقل 29: يجب أن يطابق رمز المركز الجمركي ('+oc+')','c28g');
 if(emp(H.c30c))e('الحقل 30: مكان وجود البضاعة غير مكتوب','c30c');else if(String(H.c30c).trim().split('/')[0]!==oc)e('الحقل 30: يجب أن يبدأ برمز المركز الجمركي ('+oc+') مثل '+oc+'/1','c30c');
 /* البنود */
 var sumPk=0,sumPr=0,used=0;
 I.forEach(function(it,k){var any=Object.keys(it).some(function(n){return n!=='i32'&&!emp(it[n])&&it[n]!==false});if(k>0&&!any)return;used++;var t='البند '+(k+1)+': ';
  [['i33','البند الجمركي (33)'],['i37a','الوضع الجمركي (37)'],['i34a','بلد المنشأ (34)'],['i35','الوزن القائم (35)'],['i38','الوزن الصافي (38)'],['i31pk','نوع الطرد (31)'],['i31cnt','عدد الطرود (31)'],['i41b','ثمن السلعة (42)'],['desc1','وصف البضاعة (31)']].forEach(function(f){if(emp(it[f[0]]))e(t+f[1]+' غير مكتوب',f[0],k)});
  var bl=!emp(it.i40b);if(mfOn&&!bl)e(t+'رقم بوليصة الشحن (40) غير مكتوب وهو مطلوب لأن رقم المانيفست مكتوب','i40b',k);if(!mfOn&&bl)e(t+'رقم المانيفست غير مكتوب وهو مطلوب لأن رقم بوليصة الشحن (40) مكتوب','manifest');var pc=num(it.i31cnt),pr=num(it.i41b);if(!isNaN(pc))sumPk+=pc;if(!isNaN(pr))sumPr+=pr});
 /* عدد الطرود الكلي (6) = مجموع طرود البنود */
 if(emp(H.pkgs6))e('الحقل 6: عدد الطرود الكلي غير مكتوب (يجب أن يساوي '+sumPk+')','pkgs6');
 else if(num(H.pkgs6)!==sumPk)e('الحقل 6: عدد الطرود الكلي ('+H.pkgs6+') لا يساوي مجموع طرود البنود ('+sumPk+')','pkgs6');
 /* المبلغ الإجمالي للفاتورة (22) = مجموع أسعار البنود */
 var inv=num(H.c22a);if(isNaN(inv)||inv===0)e('الحقل 22: المبلغ الإجمالي للفاتورة غير مكتوب (يجب أن يساوي '+fmt(sumPr)+')','c22a');
 else if(Math.abs(inv-sumPr)>0.005)e('الحقل 22: المبلغ الإجمالي للفاتورة ('+fmt(inv)+') لا يساوي مجموع أسعار البنود ('+fmt(sumPr)+')','c22a');
 if(window.cvProblems&&!isNaN(inv)&&inv>0)cvProblems().forEach(function(m){e(m,'c22a')});
 if(window.reqDocs){var rq=reqDocs(mfOn),A=FD.att||{},SC=FD.docs||[];
  rq.forEach(function(r){if(!(A[r[0]]&&!emp(A[r[0]].ref))){docErr++;e('الوثيقة المرفقة: لم يتم إدخال الوثيقة '+r[0]+' ('+r[1]+')')}});
  rq.forEach(function(r){if(!SC.some(function(d){return d.code===r[0]&&d.up})){docErr++;e('المسح الضوئي: لم يتم رفع المستند '+r[0]+' ('+r[1]+')')}})}
 document.querySelectorAll('#sad .fbad').forEach(function(x){x.classList.remove('fbad')});
 bad.forEach(function(b){var el=Q(b[0],b[1]);if(!el&&b[1]!==undefined&&b[1]!==null)el=null;if(el)el.classList.add('fbad')});
 if(!err.length){calcFees();if(!quiet)infoMsg('تم التحقق من الوثيقة')}
 else{if(err.length===docErr)calcFees();else FD.fees=null;showMsgs(err.map(function(x){return 'خطأ: '+x}))}
 return !err.length};

/* ---------- حساب الرسوم (نفس حاسبة الموقع) ---------- */
var RULES={'5%':[1,0.5],'10%':[3,0.5],'15%':[3,0.5],'30%':[3,0.5]},DECL_FEE=81000;
function setV(n,k,v){var it=(FD.items[k]=FD.items[k]||{});it[n]=v;var el=Q(n,k);if(el)el.value=v}
function setH(n,v){FD.hdr[n]=v;var el=Q(n);if(el)el.value=v}
function I(x){return Math.round(x).toLocaleString('en-US')}
window.fillPageTot=function(){fillPageTot()};window.calcFees=function(){return calcFees()};
function calcFees(){var grand=0,used=window.cvUsed?cvUsed():[0],F={tot:{},sum:0,by:{}};
 (FD.items||[]).forEach(function(x,k){for(var r=0;r<8;r++)['A','B','C','D','E'].forEach(function(c){setV(c+r,k,'')})});
 used.forEach(function(k){var it=FD.items[k]||{},base=Math.round(cvCalc(k).total),key=String(it.i33||'').slice(0,8),row=(window.TARIFF||[]).filter(function(x){return String(x[0])===key})[0]||[];
  var pct=parseFloat(row[5])||0,rule=RULES[row[5]]||[0,0.5],tax=(typeof row[6]==='number'&&isFinite(row[6]))?row[6]:rule[0],exp=rule[1];
  var lines=[['001',pct,1000],['089',tax,1000],['096',exp,1]].filter(function(l){return l[1]>0}).map(function(l){var v=base*l[1]/100;return {c:l[0],p:l[1],a:l[2]===1?Math.round(v):Math.round(v/1000)*1000}});
  lines.forEach(function(l){F.by=F.by||{};F.by[l.c]=(F.by[l.c]||0)+l.a});var tot=lines.reduce(function(s,l){return s+l.a},0);grand+=tot;F.tot[k]=tot;setV('i46',k,I(base));
  lines.forEach(function(l,i){setV('A'+i,k,l.c);setV('B'+i,k,I(l.b===undefined?base:base));setV('C'+i,k,l.p.toFixed(3));setV('D'+i,k,I(l.a));setV('E'+i,k,'1')})});
 F.sum=grand;FD.fees=F;setV('tot',0,I(F.tot[0]||0));setH('pn2','0');setH('g1',I(DECL_FEE));setH('g2',I(grand+DECL_FEE));fillPageTot();
 return {grand:grand+DECL_FEE}}
function fillPageTot(){if(!FD.fees||FD.page===0)return;var k0=3*(FD.page-1)+1;for(var j=0;j<3;j++){var v=FD.fees.tot[k0+j];setH('tot'+(j+1),v===undefined?'':I(v))}setH('gt',I(FD.fees.sum))}
var ob=window.buildFinalTab;window.buildFinalTab=function(){ob();if(FD&&FD.tab===0)attachFinal()};
})(window.SIM);
