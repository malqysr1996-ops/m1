/* صفحة «القيمة الإجمالية لدى الجمارك» — محاكي تدريبي */
(function(S){
var RATES={USD:1520,EUR:1498.86,GBP:1900,AED:359.428,CNY:196.909,TRY:46,JPY:10,SAR:405,KWD:4940,IQD:1}; /* أسعار تدريبية وهمية */
window.CV_RATES=RATES;
var ROWS=['المبلغ الإجمالي للفاتورة','الشحـــن الخـــارجي','إضـــافـــة إختيـــاريـــة','قيمـــة التأميـــن','تكاليف اخرى (تجريم)','التخفيضـــــــــات'];
function f(x,d){return Number(x||0).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d})}
function N(v){var n=num(v);return isNaN(n)?0:n}
function emp(v){return v===undefined||v===null||String(v).trim()===''}
function used(){var a=[];(FD.items||[]).forEach(function(it,k){var any=Object.keys(it).some(function(n){return n!=='i32'&&!emp(it[n])&&it[n]!==false});if(k===0||any)a.push(k)});return a}
function st(key){FD.cv=FD.cv||{};return FD.cv[key]=FD.cv[key]||{r:[{},{},{},{},{},{}]}}
function amt0(key){return key==='g'?N(FD.hdr.c22a):N((FD.items[key]||{}).i41b)}
function cur(){return String(FD.hdr.c22b||'').toUpperCase()}
function calc(key){var s=st(key),rows=[];for(var i=0;i<6;i++){var r=s.r[i],a=i===0?amt0(key):N(r.a),rate=RATES[(r.code||'').toUpperCase()]||0;rows.push({a:a,code:r.code||'',rate:rate,q:Math.round(a*rate)})}
 var exp=rows[1].q+rows[2].q+rows[3].q+rows[4].q-rows[5].q;return {rows:rows,exp:exp,total:rows[0].q+exp}}
window.cvCalc=calc;window.cvUsed=used;
window.cvProblems=function(){var out=[],c=cur();
 function chk(key,lab){var r=st(key).r[0],code=(r.code||'').toUpperCase();if(!code||!RATES[code]||code!==c)out.push('الحقل 22: يجب تحويل رمز FCX إلى '+(c||'عملة الفاتورة')+' في صفحة القيمة الإجمالية لدى الجمارك ('+lab+')')}
 chk('g','القسم العام');used().forEach(function(k){chk(k,'البند '+(k+1))});return out};
window.cvFlag=function(){var a=document.querySelector('#sad [data-n="c22a"]');if(!a)return;snapFinal();var on=N(FD.hdr.c22a)>0&&cvProblems().length>0;a.classList.toggle('fbad',on)};
function codeInput(val,key,i,ro){return '<input class="cv-i cv-c" data-key="'+key+'" data-i="'+i+'" value="'+val+'" maxlength="3" style="direction:ltr;text-align:left">'}
function render(){
 var b=$('fbody'),key=FD.cvSel===undefined?'g':FD.cvSel,u=used();if(key!=='g'&&u.indexOf(+key)<0)key=FD.cvSel='g';
 var c=calc(key),tabs='<div class="cv-t'+(key==='g'?' on':'')+'" data-k="g">1</div>'+u.map(function(k,i){return '<div class="cv-t'+(String(key)===String(k)?' on':'')+'" data-k="'+k+'">'+(i+2)+'</div>'}).join('');
 var h='<div class="cvwrap"><div class="cv-tabs">'+tabs+'</div><div class="cvmain"><div class="cv-ban"></div><div class="cv-hd">البيان الموحد - ملاحظة التسعير - '+(key==='g'?'القسم العام':'البند')+'</div>';
 h+='<div class="cv-box">';
 if(key==='g')h+='<div class="cv-r0"><span>طريقة العمل</span><b>رقم توزيع , الإجماليات المحسوبة</b></div>';else h+='<div class="cv-r0"><span>رقم البند</span><b>'+(+key+1)+'</b></div>';
 h+='<div class="cv-g cv-gh"><span></span><span>المبلغ</span><span></span><span>رمز FCX</span><span>معدل التحويل</span><span>الكمية في IQD</span></div>';
 for(var i=0;i<6;i++){var r=c.rows[i];h+='<div class="cv-g"><span class="cv-l">'+ROWS[i]+'</span>'+('<input class="cv-i cv-a" data-key="'+key+'" data-i="'+i+'" value="'+f(r.a,2)+'">')+'<span>في</span>'+codeInput(r.code,key,i)+'<input class="cv-i" readonly value="'+f(r.rate,3)+'"><input class="cv-i" readonly value="'+f(r.q,0)+'"></div>'}
 h+='<div class="cv-g2"><span>مجموع المصاريف</span><input class="cv-i" readonly value="'+f(c.exp,0)+'"></div>';
 if(key==='g'){var gw=0;(FD.items||[]).forEach(function(it){gw+=N(it.i35)});h+='<div class="cv-g2"><span>الوزن القائم الاجمالي</span><input class="cv-i" readonly value="'+(gw?f(gw,3):'')+'"><span>شروط التسليم</span><input class="cv-i" value="FOB" style="width:70px"></div>'}
 else h+='<div class="cv-g2"><span>شروط التسليم</span><input class="cv-i" value="FOB" style="width:70px"></div>';
 h+='<div class="cv-g2"><span>'+(key==='g'?'القيمة الاجمالية للبيان':'القيمة الاجمالية للبيان')+'</span><input class="cv-i" readonly value="'+f(c.total,0)+'"></div>';
 if(key!=='g')h+='<div class="cv-g2"><span>القيمة الاحصائية</span><input class="cv-i" readonly value="'+f(c.total,0)+'"></div>';
 h+='</div>';
 if(key!=='g')h+='<div class="cv-box cv-b2"><div class="cv-cap">معلومات اضافية</div>'+[1,2].map(function(n){return '<div class="cv-g3"><span class="cv-l">الوحدة الاضافية '+n+'</span><span>الرمز</span><input class="cv-i"><span>الاسم</span><input class="cv-i" style="width:300px"><span>الكمية</span><input class="cv-i"></div>'}).join('')+'<div class="cv-g3"><span class="cv-l">القيمة السوقية</span><span>معدل (%)</span><input class="cv-i"><span>من طرف</span><input class="cv-i"></div><div class="cv-g3"><span class="cv-l"></span><span>القاعدة</span><input class="cv-i"><span>المبلغ</span><input class="cv-i"></div></div>';
 h+='</div></div>';
 b.innerHTML=h;
 b.querySelectorAll('.cv-t').forEach(function(t){t.onclick=function(){FD.cvSel=t.getAttribute('data-k');render()}});
 b.querySelectorAll('.cv-a').forEach(function(e){e.onblur=function(){var n=num(e.value);n=isNaN(n)?0:n;var k=e.getAttribute('data-key'),i=+e.getAttribute('data-i');if(i===0){if(k==='g')FD.hdr.c22a=f(n,2);else(FD.items[+k]=FD.items[+k]||{}).i41b=f(n,2)}else st(k).r[i].a=n;render()};e.onkeydown=function(ev){if(ev.key==='Enter')e.blur()}});
 b.querySelectorAll('.cv-c').forEach(function(e){var k=e.getAttribute('data-key'),i=+e.getAttribute('data-i');
  function set(code){st(k).r[i].code=code;render()}
  function pop(){var d=dropdown(e,S.currencies,function(x){return '<span>'+x.n+'</span><b>'+x.c+'</b>'},function(x){set(x.c)});d.style.top=(parseFloat(d.style.top)+b.scrollTop)+'px';d.style.maxHeight='200px'}
  e.ondblclick=pop;e.onkeydown=function(ev){if(ev.key==='F4'){ev.preventDefault();pop()}if(ev.key==='Enter')e.blur()};
  e.onblur=function(){setTimeout(function(){var v=e.value.trim().toUpperCase();if(v===(st(k).r[i].code||''))return;if(!v)return set('');var ok=S.currencies.some(function(x){return String(x.c).toUpperCase()===v});set(ok?v:'')},120)}});
 if(typeof fFlags==='function')fFlags()}
(function(){var s=document.createElement('style');s.textContent='.cvwrap{display:flex;direction:rtl;width:min(1000px,96%);margin:6px auto;background:#fff;align-items:flex-start}.cv-tabs{width:28px;flex:none;margin-top:66px}.cv-t{margin-bottom:2px;background:#bcc3d3;text-align:center;font:700 12px Tahoma;padding:5px 0;cursor:pointer;color:#333}.cv-t.on{background:#e3242b;color:#fff}.cvmain{flex:1;min-width:0}.cv-ban{height:58px;background:url(final-banner.jpg) right center/cover no-repeat}.cv-hd{background:#046a5a;color:#fff;font:700 13px Tahoma;padding:6px 14px;margin:4px 0 14px}.cv-box{border:2px solid #0a7a3c;margin:0 4px 10px;padding:14px 16px;font:11px Tahoma;direction:rtl}.cv-b2{position:relative;padding-top:20px}.cv-cap{position:absolute;top:-9px;right:10px;background:#fff;padding:0 4px;font:11px Tahoma}.cv-r0{margin-bottom:14px;display:flex;gap:18px}.cv-r0 b{font-weight:400;border-bottom:1px solid #aaa;padding:0 8px;min-width:200px}.cv-g,.cv-g2,.cv-g3{display:flex;align-items:center;gap:8px;margin-bottom:12px}.cv-gh span{font-size:10px;font-weight:700;width:140px}.cv-gh span:first-child{width:170px}.cv-l{width:170px;font-weight:700;flex:none}.cv-g>span:nth-child(3){width:22px;text-align:center;font-size:10px}.cv-i{border:0;border-bottom:1px solid #aaa;background:transparent;font:11px Tahoma;width:140px;text-align:right;direction:ltr;padding:1px 2px;outline:0}.cv-i:focus{background:#dcd7f7}.cv-g2 span{margin-left:6px;font-weight:700}.cv-g3 span{font-size:10px}.cv-c{width:60px}';document.head.appendChild(s)})();
var ob=window.buildFinalTab;window.buildFinalTab=function(){ob();
 if(FD.tab===1){snapFinal();render();return}
 if(FD.tab===0&&FD.page===0){['c22a','c22b'].forEach(function(n){var e=document.querySelector('#sad [data-n="'+n+'"]');if(e)['input','blur','change'].forEach(function(ev){e.addEventListener(ev,function(){setTimeout(cvFlag,160)})})});cvFlag()}};
})(window.SIM);
