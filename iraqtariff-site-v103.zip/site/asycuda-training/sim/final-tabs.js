/* التصفية + الوثيقة المرفقة + المسح الضوئي للمستند — البيان النهائي (تدريبي) */
(function(S){
var GEN=[['039','كشف البضائع',25000],['034','اجور السونار',30000],['031','الوزن',5000],['013','امانات بناء مدارس',1000],['011','رسوم الطوابع المالية',15000],['037','ختم سيل رصاص',5000]];
var ITN={'001':'الوارد الكمركي على القطاع الخاص','089':'الامانات الضريبية','096':'امانات رسم دعم التصدير'};
var DOCN={'001':'فاتورة','003':'شهادة منشأ','004':'بوليصة شحن','005':'هوية الاستيراد او الهوية التصديرية','008':'أمر التسليم','056':'ايصال التتبع الالكتروني','057':'وكالة كمركية او تحويل او تفويض','994':'المطابقة والسيطرة النوعية'};
function emp(v){return v===undefined||v===null||String(v).trim()===''}
function f0(x){return Math.round(x).toLocaleString('en-US')}
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;')}
function mfOn(){var m=FD.hdr.manifest;return !emp(m)&&m!=='2026/'}
/* الوثائق المطلوبة (الترتيب مثل ASYCUDA) */
window.reqDocs=function(sea){var o=['057','008','003','001','056','005','994','004'];return o.filter(function(c){return (c!=='004'&&c!=='008')||sea}).map(function(c){return [c,DOCN[c]]})};
function usedCount(){return window.cvUsed?cvUsed().length:1}
function head(title,extra){
 var H=FD.hdr,o=fOff();
 return '<div class="cvwrap tbw"><div class="cvmain"><div class="cv-ban"></div><div class="cv-hd">'+title+'</div>'+(extra||'')+
 '<div class="tb-box"><div class="tb-r"><div><span>الأمانة الجمركية</span><b>'+o.c+' &nbsp; '+esc(o.n)+'</b></div><div><span>تعريف البيان</span><b></b></div></div>'+
 '<div class="tb-r"><div style="width:90px"><span>نموذج</span><b>'+esc(H.b1c||'')+' &nbsp; '+esc(H.b1b||'')+'</b></div><div style="width:200px"><span>رقم و تاريخ تسجيل البيان</span><b>'+(FD.reg?FD.reg.date+' &nbsp; '+'C '+FD.reg.no:'')+'</b></div><div style="width:200px"><span>رقم مرجع المصرح</span><b>'+esc(H.ref7a||'')+'</b></div><div style="width:200px"><span>مرجعية التصفية</span><b>/</b></div><div style="width:70px"><span>عدد الأقلام</span><b>'+usedCount()+'</b></div></div>'+
 '<div class="tb-r"><div style="width:300px"><span>المصرح /الوكيل</span><b>25000073</b></div><div style="width:300px"><span>الشركة</span><b>'+esc(H.imp_no||'')+'</b></div></div>'+
 '<div class="tb-r"><div style="width:300px;font-weight:700">وكيل الاخراج: (اسم تدريبي)<br>بغداد - تدريبي</div><div style="width:300px;font-weight:700;white-space:pre-line">'+esc(H.imp_addr||'')+'</div></div></div>'}
/* ============ التصفية ============ */
function liq(){
 var b=$('fbody');if(FD.fees)calcFees();var F=FD.fees,by=F?F.by||{}:{},ok=!!F;
 var gen=ok?GEN:[],gs=gen.reduce(function(s,g){return s+g[2]},0),it=['001','089','096'].filter(function(c){return by[c]}),is=it.reduce(function(s,c){return s+by[c]},0);
 var h=head('البيان الموحد - ملاحظة التسعير - التصفية','<div class="tb-c">'+(FD.reg?'':'**** البيان لم يصفى بعد ****')+'</div>');
 h+='<div class="tb-box"><div class="tb-r"><div style="width:200px"><span>طريقة الدفع</span><b>'+(ok?'الدفع نقداً':'')+'</b></div><div style="width:150px"><span>رقم الحساب</span><b></b></div><div style="width:220px"><span>رقم و تاريخ الايصال</span><b></b></div><div style="width:220px"><span>رقم وتاريخ الاقرار</span><b></b></div></div>';
 h+='<div class="tb-two"><div class="tb-col"><div class="tb-cap">ضرائب الأقلام</div>';
 for(var i=0;i<12;i++){var c=it[i];h+='<div class="tb-l"><i class="c">'+(c||'')+'</i><i class="d">'+(c?ITN[c]:'')+'</i><i class="a">'+(c?f0(by[c]):'')+'</i></div>'}
 h+='</div><div class="tb-col"><div class="tb-cap">الضرائب العامة</div>';
 for(var j=0;j<12;j++){var g=gen[j];h+='<div class="tb-l"><i class="c">'+(g?g[0]:'')+'</i><i class="d">'+(g?g[1]:'')+'</i><i class="a">'+(g?f0(g[2]):'')+'</i></div>'}
 h+='<div class="tb-tot"><div><span>مجموع الضرائب العامة</span><b>'+(ok?f0(gs):'')+'</b></div><div><span>مجموع الضرائب على الأقلام</span><b>'+(ok?f0(is):'')+'</b></div><div style="margin-top:22px"><span>مجموع المبلغ المصفى على البيان</span><b>'+(ok?f0(gs+is):'')+'</b></div><div><span>المبلغ المتوجب</span><b></b></div></div></div></div></div></div></div>';
 b.innerHTML=h;fFlags()}
/* ============ الوثيقة المرفقة ============ */
function att(){return FD.att=FD.att||{}}
function attPage(){
 var b=$('fbody'),rq=reqDocs(mfOn()),A=att(),sel=FD.attSel,ed=FD.attEdit;
 var rows=rq.map(function(r){var a=A[r[0]]||{},got=!emp(a.ref);return '<tr data-c="'+r[0]+'" class="'+(got?'':'miss')+(sel===r[0]?' on':'')+'"><td>1</td><td>'+r[0]+'</td><td>'+r[1]+'</td><td>'+esc(a.ref||'')+'</td><td>'+esc(a.date||'')+'</td></tr>'}).join('');
 var cur=rq.filter(function(r){return r[0]===ed})[0],a=A[ed]||{};
 var h=head('البيان الموحد - صفحة الوثائق المرفقة');
 h+='<div class="tb-box"><div class="tb-r" style="align-items:flex-end"><div style="width:40px"><span>البند</span><b>'+(cur?1:'')+'</b></div><div style="width:60px"><span>الرمز</span><b>'+(cur?cur[0]:'')+'</b></div><div style="width:300px"><span>الوصف</span><b>'+(cur?cur[1]:'')+'</b></div><div style="width:200px"><span>الرقم المرجعي</span>'+(cur?'<input id="atRef" class="tb-in" value="'+esc(a.ref||'')+'">':'<b></b>')+'</div><div style="width:130px"><span>التاريخ</span><b>'+esc(a.date||'')+'</b></div><div style="width:30px"><b id="atSave" style="cursor:pointer;border:0;font-size:18px" title="إدخال">'+(cur?'⬇':'')+'</b></div></div>';
 h+='<table class="tb-t"><tr><th style="width:40px">البند</th><th style="width:60px">الرمز</th><th>الوصف</th><th style="width:200px">الرقم المرجعي</th><th style="width:130px">التاريخ</th></tr>'+rows+'</table></div></div></div>';
 b.innerHTML=h;fFlags();
 var save=function(){var r=$('atRef');if(!r||!ed)return;var v=r.value.trim();if(!v){infoMsg('الرقم المرجعي مطلوب.');return}att()[ed]={ref:v,date:new Date().toLocaleDateString('en-GB')};FD.attEdit=null;attPage()};
 if($('atSave'))$('atSave').onclick=save;if($('atRef')){$('atRef').onkeydown=function(e){if(e.key==='Enter')save()};setTimeout(function(){var r=$('atRef');if(r)r.focus()},0)}
 b.querySelectorAll('tr[data-c]').forEach(function(tr){var c=tr.getAttribute('data-c');tr.onclick=function(){FD.attSel=c;attPage()};
  tr.oncontextmenu=function(e){FD.attSel=c;showCtx(e,[['تعديل',function(){FD.attEdit=c;attPage()}],['حذف',function(){delete att()[c];attPage()}],['استعراض',function(){var x=att()[c]||{};infoMsg('الوثيقة '+c+' — '+DOCN[c]+'<br>الرقم المرجعي: '+(x.ref||'—'))}]])}})}
/* ============ المسح الضوئي للمستند ============ */
function docs(){return FD.docs=FD.docs||[]}
function scan(){
 var b=$('fbody'),H=FD.hdr;
 b.innerHTML='<div class="sheet docs" id="sheet" style="margin:10px auto;width:min(900px,96%)"><h2 class="tl" style="text-align:right">ملخص المسح الضوئي</h2>'+
 '<div class="row" style="border-top:1px solid #000"><div class="cell" style="flex:.5"><div class="lb">المصرح</div><b>25000073</b></div><div class="cell"><div class="lb">الشركة المستوردة</div><b>'+esc(H.imp_no||'')+'</b></div><div class="cell"><div class="lb">نوع البيان</div><b>'+esc(H.b1c||'')+' '+esc(H.b1b||'')+'</b></div></div>'+
 '<div style="margin:12px 0 2px;font-weight:700;color:#0a6b4a;font-size:11px">المستندات الممسوحة ضوئيا</div>'+
 '<div class="dtb"><div class="ib" id="dDel" title="حذف">✖</div><div class="ib" id="dSave" title="حفظ">💾</div><div class="ib" id="dAdd" title="إضافة ملف">📄</div><div class="sp"></div><div class="ib" id="dView" title="عرض">🔍</div><div class="ib" id="dStop">■</div><div class="ib" id="dPause">❚❚</div><div class="ib" id="dUp" title="رفع">⬆</div></div>'+
 '<table id="dt"></table><input type="file" id="dFile" style="display:none" accept=".pdf,.png,.jpg,.jpeg,.tif,.tiff"></div>';
 fFlags();rd();
 $('dAdd').onclick=function(){$('dFile').click()};
 $('dFile').onchange=function(){var f=this.files[0];if(!f)return;docs().push({name:f.name,size:f.size,pct:0,code:'',desc:'',up:false});FD.selDoc=docs().length-1;this.value='';rd()};
 $('dDel').onclick=function(){if(FD.selDoc==null)return;docs().splice(FD.selDoc,1);FD.selDoc=null;rd()};
 $('dUp').onclick=function(){var d=docs()[FD.selDoc==null?docs().length-1:FD.selDoc];if(!d){infoMsg('اختر ملفاً أولاً.');return}if(!d.code){infoMsg('حدد نوع المستند (Code) قبل الرفع.');return}d.pct=100;d.up=true;rd();infoMsg('تم التحميل بنجاح')};
 $('dSave').onclick=function(){infoMsg('تم الحفظ (تدريبي).')};['dView','dStop','dPause'].forEach(function(i){$(i).onclick=function(){}})}
function rd(){var t=$('dt'),D=docs();var h='<tr><th style="width:90px">Status</th><th>File name</th><th>Description</th><th style="width:70px">Code</th></tr>';
 D.forEach(function(d,i){h+='<tr data-i="'+i+'" class="'+(FD.selDoc===i?'sel':'')+'"><td>'+(d.up?'⇧ 100 %':d.pct+' %')+'</td><td>'+esc(d.name)+'</td><td style="direction:rtl">'+esc(d.desc)+'</td><td data-code="1" style="cursor:pointer">'+(d.code||'▽')+'</td></tr>'});
 for(var k=D.length;k<6;k++)h+='<tr><td></td><td></td><td></td><td></td></tr>';t.innerHTML=h;
 t.querySelectorAll('tr[data-i]').forEach(function(tr){var i=+tr.getAttribute('data-i');tr.onclick=function(){FD.selDoc=i;rd()};
  var cd=tr.querySelector('[data-code]');cd.onclick=function(e){e.stopPropagation();FD.selDoc=i;
   var inp=document.createElement('input');inp.className='in num';inp.value=D[i].code;inp.style.width='100%';cd.innerHTML='';cd.appendChild(inp);inp.focus();
   function setDoc(x){D[i].code=x.c;D[i].desc=x.n;rd()}
   function res(){var x=S.docTypes.filter(function(z){return z.c===inp.value.trim().padStart(3,'0')})[0];if(x)setDoc(x);else rd()}
   inp.addEventListener('keydown',function(e){if(e.key==='Enter')res()});inp.addEventListener('blur',function(){setTimeout(function(){if(inp.parentNode)res()},150)});
   var dd=dropdown(inp,S.docTypes,function(x){return '<span>'+x.n+'</span><b>'+x.c+'</b>'},setDoc);dd.style.direction='rtl'}})}
/* ============ ربط ============ */
(function(){var s=document.createElement('style');s.textContent='.tbw{width:min(1000px,96%)}.tb-box{border:2px solid #0a7a3c;margin:0 4px 10px;padding:10px 16px;font:11px Tahoma;direction:rtl;background:#fff}.tb-r{display:flex;gap:14px;margin-bottom:12px}.tb-r>div{flex:none}.tb-r span{display:block;font:700 10px Tahoma;color:#0a6b4a;margin-bottom:3px}.tb-r b{display:block;font-weight:400;border-bottom:1px solid #aaa;min-height:15px;padding:0 4px}.tb-c{text-align:center;font:700 11px Tahoma;margin:-6px 0 8px}.tb-in{border:0;border-bottom:1px solid #d33;background:#e6c8f2;font:11px Tahoma;width:100%;direction:ltr;outline:0}.tb-t{width:100%;border-collapse:collapse;font:10px Tahoma;margin-top:6px}.tb-t th{background:#dfe4ef;border:1px solid #98a2ba;font-weight:400;padding:2px}.tb-t td{border:1px solid #c5ccdc;padding:2px 6px;height:17px;cursor:pointer}.tb-t tr.miss td{background:#f4929a;color:#222}.tb-t tr.on td{background:#0b0b78;color:#fff}.tb-t tr.miss.on td{background:#d9a0e6;color:#000}.tb-t tr:not(.miss):not(.on) td{background:#fff}.tb-two{display:flex;direction:rtl;gap:20px}.tb-col{flex:1}.tb-cap{font:700 10px Tahoma;color:#0a6b4a;margin:8px 0 4px}.tb-l{display:flex;direction:rtl;gap:8px;height:19px;align-items:flex-end}.tb-l i{font:11px Tahoma;font-style:normal;border-bottom:1px solid #bbb;height:17px;overflow:hidden;white-space:nowrap}.tb-l .c{width:40px}.tb-l .d{flex:1}.tb-l .a{width:90px;text-align:left;direction:ltr}.tb-tot{border:1px solid #0a7a3c;margin-top:12px;padding:6px 10px}.tb-tot>div{display:flex;gap:10px;align-items:flex-end;margin-bottom:8px}.tb-tot span{font:700 10px Tahoma;color:#0a6b4a;flex:1}.tb-tot b{width:110px;font-weight:400;border-bottom:1px solid #aaa;direction:ltr;text-align:left;min-height:15px}';document.head.appendChild(s)})();
var ob=window.buildFinalTab;window.buildFinalTab=function(){
 if(FD.tab===3||FD.tab===6){snapFinal();$('fbody').innerHTML='';fFlags();return}
 if(FD.tab===2||FD.tab===4||FD.tab===5){snapFinal();var b=$('fbody');b.innerHTML='';if(FD.tab===2)liq();else if(FD.tab===4)attPage();else scan();return}
 ob()};
})(window.SIM);
