/* مدير النوافذ: تبقى النوافذ المفتوحة (بيان مسبق / بيان نهائي / رقم الإجراء الموحد) متاحة بشريط سفلي */
(function(){
var WINS=[],ACT=null,UID=0;
var st=document.createElement('style');
st.textContent='#wbar{position:absolute;left:0;right:0;bottom:0;height:26px;display:none;direction:rtl;gap:6px;align-items:center;background:#ebe5cf;border-top:1px solid #8f8869;padding:2px 10px;font:12px Tahoma;color:#222;z-index:30;overflow:hidden;white-space:nowrap}#wbar span{padding:2px 12px;border:1px solid #b9b293;border-radius:2px;cursor:pointer;max-width:240px;overflow:hidden;text-overflow:ellipsis}#wbar span:hover{background:#e0d9bd}#wbar span.on{border-color:#8f8869;background:#d6cfb4;font-weight:700}.ws.hasbar .win,.ws.hasbar .home{bottom:26px}.ws.hasbar .ftask{display:none}';
document.head.appendChild(st);
var ws=$('ws'),bar=document.createElement('div');bar.id='wbar';ws.appendChild(bar);
function title(e){var t=$('wtt')||$('ftt')||$('utt');return t?t.textContent:e.kind}
function render(){var all=WINS.concat(ACT?[ACT]:[]).sort(function(a,b){return a.id-b.id});
 bar.style.display=all.length?'flex':'none';ws.classList.toggle('hasbar',all.length>0);
 bar.innerHTML='';all.forEach(function(e){var s=document.createElement('span');s.textContent=e===ACT?title(e):e.title;if(e===ACT)s.className='on';s.onclick=function(){if(e!==ACT)activate(e)};bar.appendChild(s)})}
function stash(){if(!ACT)return;var w=$('win'),h=document.createElement('div');
 ACT.title=title(ACT);while(w.firstChild)h.appendChild(w.firstChild);
 ACT.holder=h;ACT.cls=w.className;ACT.S={D:D,FD:FD,F:F};WINS.push(ACT);ACT=null;w.className='win';
 if(typeof closeDD==='function')closeDD()}
function activate(e){stash();var w=$('win');WINS.splice(WINS.indexOf(e),1);
 $('home').style.display='none';w.className=e.cls;while(e.holder.firstChild)w.appendChild(e.holder.firstChild);
 D=e.S.D;FD=e.S.FD;F=e.S.F;ACT=e;e.holder=null;render()}
function openKind(kind,fn){return function(){stash();var r=fn.apply(this,arguments);ACT={id:++UID,kind:kind};addClose(kind);render();return r}}
function addClose(kind){var tb=document.querySelector('#win .ftb');if(!tb||tb.querySelector('.fclose'))return;
 var c=document.createElement('div');c.className='fi fclose';c.title='إغلاق';c.innerHTML='<span style="color:#c00;font:700 22px Arial">✕</span>';
 c.onclick=function(){closeWin()};var gap=tb.querySelector('.fgap');tb.insertBefore(c,tb.querySelector('.tt'))}
window.openAdv=openKind('adv',window.openAdv);window.openFinal=openKind('final',window.openFinal);window.newUni=openKind('uni',window.newUni);
var ob=window.soon;window.soon=openKind('soon',ob);
window.closeWin=function(){var w=$('win');ACT=null;w.className='win';w.innerHTML='';
 if(WINS.length){activate(WINS[WINS.length-1]);return}
 $('home').style.display='flex';render()};
/* تحديث عنوان الشريط عند تغيّر العنوان (مثلاً بعد التسجيل) */
setInterval(function(){if(ACT)render()},800);
})();
